#include <stdio.h>
#import <CoreFoundation/CoreFoundation.h>

#include "hid-support-internal.h"
#include "GSEvent.h"
#import "hid-support.h"
#define INVALID_RESULT -5

static CFMessagePortRef hid_support_message_port = 0;

static void hid_message_port_refresh(){
	// still valid
	if (hid_support_message_port && !CFMessagePortIsValid(hid_support_message_port)){
		CFRelease(hid_support_message_port);
		hid_support_message_port = NULL;
	}
	// create new one
	if (!hid_support_message_port) {
		hid_support_message_port = CFMessagePortCreateRemote(NULL, CFSTR(HID_SUPPORT_PORT_NAME));
	}
    
}

static int hid_send_message(hid_event_type_t cmd, uint16_t dataLen, uint8_t *data, CFDataRef *resultData){
	// check for port
	hid_message_port_refresh();
	
	if (!hid_support_message_port) {
		printf("hid_send_message cannot find server " HID_SUPPORT_PORT_NAME "\n");
		return kCFMessagePortIsInvalid;
	}
	
	// create and send message
	CFDataRef cfData = CFDataCreate(NULL, data, dataLen);
	CFStringRef replyMode = NULL;
	if (resultData) {
		replyMode = kCFRunLoopDefaultMode;
	}
	int result = CFMessagePortSendRequest(hid_support_message_port, cmd, cfData, 1, 1, replyMode, resultData);
	if (cfData) {
		CFRelease(cfData);
	}
	return result;
}

int hid_inject_text(const char * utf8_text){
	return hid_send_message(TEXT, strlen(utf8_text), (uint8_t *) utf8_text, 0);
}

int hid_inject_key_down(uint32_t unicode, uint16_t key_modifier) {
	key_event_t event;
	event.down = 1;
	event.modifier = key_modifier;
	event.unicode = unicode;
	return hid_send_message(KEY, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_key_up(uint32_t unicode){
	key_event_t event;
	event.modifier = 0;
	event.down = 0;
	event.unicode = unicode;
	return hid_send_message(KEY, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_remote_down(uint16_t action) {
	remote_action_t event;
	event.down = 1;
	event.action = action;
	return hid_send_message(KEY, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_remote_up(uint16_t action){
	remote_action_t event;
	event.down = 0;
	event.action = action;
	return hid_send_message(KEY, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_button_down(uint16_t action){
	button_event_t event;
	event.down   = 1;
	event.action = action;
	return hid_send_message(BUTTON, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_button_up(uint16_t action){
	button_event_t event;
	event.down   = 0;
	event.action = action;
	return hid_send_message(BUTTON, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_mouse_keep_alive(){
	mouse_event_t event;
	event.type = KEEP_ALIVE;
	return hid_send_message(MOUSE, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_mouse_rel_move(uint8_t buttons, float dx, float dy){
	mouse_event_t event;
	event.type = REL_MOVE;
	event.buttons = buttons;
	event.x = dx;
	event.y = dy;
	return hid_send_message(MOUSE, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_mouse_abs_move(uint8_t buttons, float ax, float ay){
	mouse_event_t event;
	event.type = ABS_MOVE;
	event.buttons = buttons;
	event.x = ax;
	event.y = ay;
	return hid_send_message(MOUSE, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_accelerometer(float x, float y, float z){
	accelerometer_t event;
	event.x = x;
	event.y = y;
	event.z = z;
	return hid_send_message(ACCELEROMETER, sizeof(event), (uint8_t*) &event, 0);
}

int hid_inject_gseventrecord(uint8_t *event_record){
    // get size of GSEventRecord
    int size = sizeof(GSEventRecord) + ((GSEventRecord*)event_record)->infoSize;
    return hid_send_message(GSEVENTRECORD, size, event_record, 0);
}

int hid_get_screen_dimension(int *width, int *height){
    CFDataRef resultData;
    int result = hid_send_message(GET_SCREEN_DIMENSION, 0, NULL, &resultData);
    if (result < 0) {
        return result;
    }
    const dimension_t *dimension = (const dimension_t *) CFDataGetBytePtr(resultData);
    if (!dimension) {
        return INVALID_RESULT;
    }
    if (CFDataGetLength(resultData) != sizeof(dimension_t)) {
        CFRelease(resultData);
        return INVALID_RESULT;
    }
    if (width)  *width  = dimension->width;
    if (height) *height = dimension->height;
    CFRelease(resultData);
    return 0;
}
