//
//  main.m
//  SmartCar
//
//  Created by goopai on 13-3-21.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SmartCarAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SmartCarAppDelegate class]));
    }
}
