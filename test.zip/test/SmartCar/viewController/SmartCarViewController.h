//
//  SmartCarViewController.h
//  SmartCar
//
//  Created by goopai on 13-3-21.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "SettingViewController.h"
@class SmartCarAppDelegate;
@interface SmartCarViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    int selectIndex;
    CGSize size_screen;
    SmartCarAppDelegate *appDelegate;
    UILabel *nameLable;
    UILabel *stateLable;
    UITableView *table;
    UIImageView* topImage;
    UIImageView *linkImage;
    UIImageView *pointImage;
    UIImageView *stateImage;
    UIButton *backBtn;
    UIView *backView;
    UIView *showView;
    UIButton *goStart;
    NSString *deviceName;
    UIView *view;
    UILabel *dName;
    NSTimer *timer;
    NSArray *appList;
    int num;
    NSTimer *checkTimer;
    NSThread *thread;
}
@property(nonatomic,strong)NSTimer *timer;
@property int num;
@property (strong, nonatomic) UILabel *nameLable;
@property (strong, nonatomic) UILabel *stateLable;
@property (strong, nonatomic) UITableView *table;
-(void)setConnect:(NSString *)name;
-(void)checkLink:(BOOL)linked;
-(void)backToBackView;
-(void)changeBtn:(BOOL)isconnect;
-(void)checkLink:(BOOL)linked :(BOOL)connect;
-(void)reSetTimer;
-(void)changePointAnimation;
-(void)checkIsRunning:(BOOL)isRunning;
@end
