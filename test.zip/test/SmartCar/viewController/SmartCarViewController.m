//
//  SmartCarViewController.m
//  SmartCar
//
//  Created by goopai on 13-3-21.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//
#include "mouse_msgs.h"
#import "SmartCarViewController.h"
#import "SmartCarAppDelegate.h"
#import "SVProgressHUD.h"
#import <sys/sysctl.h>
#import <dlfcn.h>
#define SBSERVPATH "/System/Library/PrivateFrameworks/SpringBoardServices.framework/SpringBoardServices"
#define CellHeight 50


@implementation SmartCarViewController
@synthesize nameLable,stateLable,table,num,timer;
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [appDelegate scanPer];
    
}
- (void)loadView
{
    [super loadView];
}
-(UILabel *)creatLab:(CGRect)frame :(NSString *)name{
    UILabel *lab=[[UILabel alloc]initWithFrame:frame];
    lab.backgroundColor=[UIColor clearColor];
    lab.text=name;
    lab.textAlignment=NSTextAlignmentLeft;
    //lab.font=[UIFont systemFontOfSize:25];
    lab.font=[UIFont boldSystemFontOfSize:25];
    lab.textColor=[UIColor blackColor];
    [view addSubview:lab];
    return lab;
}
-(UIImageView *)creatImageView:(CGRect)frame :(NSString *)source{
    UIImageView *backImg=[[UIImageView alloc]initWithFrame:frame];
    [backView addSubview:backImg];
    backImg.image=[UIImage imageNamed:source];
    return backImg;
}
-(void)goBack{
    [appDelegate homeButtonPressed];
}
-(void)chooseBtdevice{
    [appDelegate scanPer];
    [UIView animateWithDuration:0.5 animations:^{
        backView.frame=CGRectMake(-size_screen.height, 0, size_screen.height, size_screen.width);
        showView.frame=CGRectMake(0, 0, size_screen.height, size_screen.width);
    }];
}
-(void)backToBackView{
    [appDelegate.peripherals removeAllObjects];
    [table reloadData];
    [UIView animateWithDuration:0.5 animations:^{
        showView.frame=CGRectMake(size_screen.height, 0, size_screen.height, size_screen.width);
        backView.frame=CGRectMake(0, 0, size_screen.height, size_screen.width);
    }];
}
- (void) getActiveApps
{
    while (1) {
        if ([[NSThread currentThread]isCancelled]) {
            [NSThread exit];
            return;
        }
        sleep(1.5);
        mach_port_t *port;
        void *lib = dlopen(SBSERVPATH, RTLD_LAZY);
        int (*SBSSpringBoardServerPort)() =
        dlsym(lib, "SBSSpringBoardServerPort");
        port = (mach_port_t *)SBSSpringBoardServerPort();
        dlclose(lib);
        void *sbserv = dlopen(SBSERVPATH, RTLD_LAZY);
        NSArray* (*SBSCopyApplicationDisplayIdentifiers)(mach_port_t* port, BOOL runningApps,BOOL debuggable) =
        dlsym(sbserv, "SBSCopyApplicationDisplayIdentifiers");
        //SBDisplayIdentifierForPID - protype assumed,verification of params done
        void* (*SBDisplayIdentifierForPID)(mach_port_t* port, int pid,char * result) =
        dlsym(sbserv, "SBDisplayIdentifierForPID");
        //SBFrontmostApplicationDisplayIdentifier - prototype assumed,verification of params done,don't call this TOO often(every second on iPod touch 4G is 'too often,every 5 seconds is not)
        void* (*SBFrontmostApplicationDisplayIdentifier)(mach_port_t* port,char * result) =
        dlsym(sbserv, "SBFrontmostApplicationDisplayIdentifier");
        
        
        
        //Get frontmost application
        char frontmostAppS[256];
        memset(frontmostAppS,sizeof(frontmostAppS),0);
        SBFrontmostApplicationDisplayIdentifier(port,frontmostAppS);
        NSString * frontmostApp=[NSString stringWithFormat:@"%s",frontmostAppS];
        //NSLog(@"Frontmost app is %@",frontmostApp);
        //get list of running apps from SpringBoard
        NSArray *allApplications = SBSCopyApplicationDisplayIdentifiers(port,NO, NO);
        //Really returns ACTIVE applications(from multitasking bar)
        /*   NSLog(@"Active applications:");
         for(NSString *identifier in allApplications) {
         // NSString * locName=SBSCopyLocalizedApplicationNameForDisplayIdentifier(p,identifier);
         NSLog(@"Active Application:%@",identifier);
         }
         */
        
        //get list of all apps from kernel
        int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
        size_t miblen = 4;
        
        size_t size;
        int st = sysctl(mib, miblen, NULL, &size, NULL, 0);
        
        struct kinfo_proc * process = NULL;
        struct kinfo_proc * newprocess = NULL;
        
        do {
            
            size += size / 10;
            newprocess = realloc(process, size);
            
            if (!newprocess){
                
                if (process){
                    free(process);
                }
                
                //return nil;
            }
            
            process = newprocess;
            st = sysctl(mib, miblen, process, &size, NULL, 0);
            
        } while (st == -1 && errno == ENOMEM);
        
        if (st == 0){
            
            if (size % sizeof(struct kinfo_proc) == 0){
                int nprocess = size / sizeof(struct kinfo_proc);
                
                if (nprocess){
                    
                    NSMutableArray * array = [[NSMutableArray alloc] init];
                    
                    for (int i = nprocess - 1; i >= 0; i--){
                        
                        int ruid=process[i].kp_eproc.e_pcred.p_ruid;
                        int uid=process[i].kp_eproc.e_ucred.cr_uid;
                        //short int nice=process[i].kp_proc.p_nice;
                        //short int u_prio=process[i].kp_proc.p_usrpri;
                        short int prio=process[i].kp_proc.p_priority;
                        NSString * processID = [[NSString alloc] initWithFormat:@"%d", process[i].kp_proc.p_pid];
                        NSString * processName = [[NSString alloc] initWithFormat:@"%s", process[i].kp_proc.p_comm];
                        
                        
                        BOOL systemProcess=YES;
                        if (ruid==501)
                            systemProcess=NO;
                        
                        
                        
                        char * appid[256];
                        memset(appid,sizeof(appid),0);
                        int intID,intID2;
                        intID=process[i].kp_proc.p_pid,appid;
                        SBDisplayIdentifierForPID(port,intID,appid);
                        
                        NSString * appId=[NSString stringWithFormat:@"%s",appid];
                        
                        if (systemProcess==NO)
                        {
                            if ([appId isEqualToString:@""])
                            {
                                //final check.if no appid this is not springboard app
                            
                            }
                            else
                            {
                                
                                BOOL isFrontmost=NO;
                                if ([frontmostApp isEqualToString:appId])
                                {
                                    isFrontmost=YES;
                                }
                                NSNumber *isFrontmostN=[NSNumber numberWithBool:isFrontmost];
                                NSDictionary * dict = [[NSDictionary alloc] initWithObjects:[NSArray arrayWithObjects:processID, processName,appId,isFrontmostN, nil]
                                                                                    forKeys:[NSArray arrayWithObjects:@"ProcessID", @"ProcessName",@"AppID",@"isFrontmost", nil]];
                                
                                [array addObject:dict];
                            }
                        }
                    }
                    
                    free(process);
                    
                    //NSLog(@"%@得到的信息",array);
                    for (NSDictionary *dic in array) {
                        if (((NSString *)[dic objectForKey:@"isFrontmost"]).boolValue==1 ) {
                            NSString *s=[dic objectForKey:@"AppID"];
                            if (![appList containsObject:s]) {
                                NSString *s1=(NSString *)[dic objectForKey:@"ProcessID"];
                                //NSLog(@"pid--%@",s1);
                                char com[20]={"kill -9 "};
                                const char *pid=[s1 UTF8String];
                                strcat(com, pid);
                                FILE* file= popen(com, "r");
                                //NSLog(@"%s",com);
                                //[appDelegate swipeReady];
                                if (file) {
                                    [appDelegate performSelectorOnMainThread:@selector(swipeReady) withObject:nil waitUntilDone:NO];
                                    //NSLog(@"com=%s pid=%s",com,pid);
                                    [self performSelectorOnMainThread:@selector(send) withObject:nil waitUntilDone:NO];
                                    pclose(file);
                                }
                              
                            }
                        }
                    }
                }
            }
        }
        
        dlclose(sbserv);
    }
}
-(void)send{
    sleep(0.6);
        sendMessage();
    //NSLog(@"发送消息");
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    appList=[[NSArray alloc]initWithObjects:@"com.google.Maps",@"com.autonavi.amap",@"com.mxnavi.UUNavi",@"com.baidu.map",@"com.tencent.QQMusic",@"com.kugou.kugou",@"com.changba.ktv",@"com.kuwo.KuwoTingting",@"com.ttpod.china",@"com.duomi.duomimusic",@"com.baidu.TingIPhone",@"com.douban.DoubanRadio",@"com.apple.mobileipod",@"com.yinyuetai.imv",@"linfengkun.NaviOne",@"com.iphonefans.TTLyrics",@"com.apple.mobilephone",@"com.apple.MobileSMS",@"com.goopai.----",@"com.apple.Preferences", nil];
    appDelegate=(SmartCarAppDelegate *)[UIApplication sharedApplication].delegate;
    CGRect rect_screen = [[UIScreen mainScreen]bounds];
    size_screen = rect_screen.size;
    
    backView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, size_screen.height, size_screen.width)];
    [self.view addSubview:backView];
    view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, size_screen.height, 100)];
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:self action:@selector(cancelConnect) forControlEvents:UIControlEventTouchUpInside];
   // [view addSubview:btn];
    btn.frame=view.bounds;
    //view.backgroundColor=[UIColor clearColor];
    dName=[self creatLab:CGRectMake(10, 0, 200, 50) :@""];
    UILabel *staLab=[self creatLab:CGRectMake(size_screen.height-120, 0, 80, CellHeight) :@"已连接"];
    staLab.textColor=[UIColor greenColor];
    [self initView];
    [self initShowView];
}

-(void)cancelConnect{
    if (appDelegate.savePeripheral&&appDelegate.savePeripheral.isConnected) {
        [appDelegate.manager cancelPeripheralConnection:appDelegate.savePeripheral];
    }
    [appDelegate scanPer];
}

-(void)checkIsRunning:(BOOL)isRunning{
    if (isRunning) {
        if (thread) {
            [thread cancel];
        }
        thread=[[NSThread alloc]initWithTarget:self selector:@selector(getActiveApps) object:nil];
        [thread start];

    }
    else{
        if (thread) {
            [thread cancel];
        }
    }
}

-(void)checkLink:(BOOL)linked :(BOOL)connect{
    
    pointImage.hidden=NO;
    for (UIImageView *img in backView.subviews) {
        if ([img isMemberOfClass:[UIImageView class]] ) {
            if (img.tag>10) {
                img.hidden=YES;
            }
        }
    }
    if (linked) {
        nameLable.hidden=NO;
        nameLable.text=deviceName;
        
        linkImage.image=[UIImage imageNamed:@"usb_link.png"];
        if (connect) {
            goStart.hidden=NO;
            backBtn.hidden=NO;
            backBtn.frame=CGRectMake((size_screen.height/2-220)/2, 252, 220, 33);
            goStart.frame=CGRectMake((size_screen.height/2-220)/2+size_screen.height/2, 252, 220, 33);
            topImage.image=[UIImage imageNamed:iPhone5?@"link_568.png":@"link.png"];
            
        }
        else{
            [self checkIsRunning:NO];
            goStart.hidden=YES;
            backBtn.frame=CGRectMake((size_screen.height-220)/2, 252, 220, 33);
            backBtn.hidden=NO;
            topImage.image=[UIImage imageNamed:iPhone5?@"nolink_2_568.png":@"nolink_2.png"];
        }
        
        
        
    }
    else{
        [self checkIsRunning:NO];
        nameLable.hidden=YES;
        backBtn.hidden=YES;
        goStart.hidden=YES;
        linkImage.image=[UIImage imageNamed:@"usb_onlink.png"];
        topImage.image=[UIImage imageNamed:iPhone5?@"nolink_1_568.png":@"nolink_1.png"];
    }
}

-(void)changePointAnimation{
    // NSLog(@"开始及时");
    
    if (timer) {
        [timer invalidate];
        timer=nil;
    }
    [self movePoint];
    timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(movePoint) userInfo:nil repeats:YES];
    
}

-(void)movePoint{
    pointImage.hidden=YES;
    num+=1;
    //NSLog(@"%d",num);
    for (UIImageView *img in backView.subviews) {
        if ([img isMemberOfClass:[UIImageView class]] ) {
            if (img.tag>10) {
                img.hidden=NO;
            }
            if (img.tag<=(num%7)+1+88&&img.tag>10) {
                img.image=[UIImage imageNamed:@"doc_g.png"];
                
            }
            if (num%7==0&&img.tag>10) {
                img.image=[UIImage imageNamed:@"doc.png"];
            }
        }
    }
}
-(void)reSetTimer{
    //NSLog(@"停止及时");
    num=0;
    [timer invalidate];
    timer=nil;
}
-(void)resetCheckTimer{
    [checkTimer invalidate];
    checkTimer=nil;
}
-(void)initView{
    [self creatImageView:CGRectMake(0, 0, size_screen.height, size_screen.width) :iPhone5?@"bg1_568.png":@"bg1.png"];
    topImage=[self creatImageView:CGRectMake(0, 0, size_screen.height, 44) :iPhone5?@"nolink_1_568.png":@"nolink_1.png"];
    linkImage=[self creatImageView:CGRectMake(size_screen.height/2-72, 174, 72, 20) :@"usb_onlink.png"];
    pointImage=[self creatImageView:CGRectMake(size_screen.height/2-72, 145, 72, 20) :@"noling_tx.png"];
    for (int i=1; i<8; i++) {
        UIImageView *point=[self creatImageView:CGRectMake(size_screen.height/2-72+11*(i-1), 150, 10, 10) :@"doc.png"];
        point.tag=i+88;
        point.hidden=YES;
    }
    
    backBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    [backView addSubview:backBtn];
    if (iPhone5) {
        backBtn.frame=CGRectMake((size_screen.height/2-220*size_screen.height/480)/2, 252, 220*size_screen.height/480, 33);
        [backBtn setBackgroundImage:[UIImage imageNamed:@"but1_568.png"] forState:UIControlStateNormal];
        [backBtn setBackgroundImage:[UIImage imageNamed:@"but1_g_568.png"] forState:UIControlStateHighlighted];
    }
    else{
        backBtn.frame=CGRectMake((size_screen.height/2-220)/2, 252, 220, 33);
        [backBtn setBackgroundImage:[UIImage imageNamed:@"but1.png"] forState:UIControlStateNormal];
        [backBtn setBackgroundImage:[UIImage imageNamed:@"but1_g.png"] forState:UIControlStateHighlighted];
    }
    
    [backBtn addTarget:self action:@selector(chooseBtdevice) forControlEvents:UIControlEventTouchUpInside];
    backBtn.hidden=YES;
    goStart=[UIButton buttonWithType:UIButtonTypeCustom];
    [backView addSubview:goStart];
    if (iPhone5) {
        goStart.frame=CGRectMake((size_screen.height/2-220*size_screen.height/480)/2+size_screen.height/2, 252, 220*size_screen.height/480, 33);
        [goStart setBackgroundImage:[UIImage imageNamed:@"but2_568.png"] forState:UIControlStateNormal];
        [goStart setBackgroundImage:[UIImage imageNamed:@"but2_g_568.png"] forState:UIControlStateHighlighted];
    }
    else{
        goStart.frame=CGRectMake((size_screen.height/2-220)/2+size_screen.height/2, 252, 220, 33);
        [goStart setBackgroundImage:[UIImage imageNamed:@"but2.png"] forState:UIControlStateNormal];
        [goStart setBackgroundImage:[UIImage imageNamed:@"but2_g.png"] forState:UIControlStateHighlighted];
    }
    
    [goStart addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    goStart.hidden=YES;
    
}
-(void)setConnect:(NSString *)name{
    deviceName=name?name:@"";
    NSString *s=name?@"text2.png":@"noling_ts.png";
    NSString *s1=name?@"doc_link.png":@"noling_tx.png";
    pointImage.image=[UIImage imageNamed:s1];
    stateImage.image=[UIImage imageNamed:s];
    
    [UIScreen screens].count==1?[self checkLink:NO :NO] :[self checkLink:YES :name?YES:NO];
    [table reloadData];
}
-(void)initShowView{
    showView=[[UIView alloc]initWithFrame:CGRectMake(size_screen.height, 0, size_screen.height, size_screen.width)];
    [self.view addSubview:showView];
    //view.backgroundColor=[UIColor clearColor];
    UIView *backgroundImg=[self creatImageView:CGRectMake(0, 0, size_screen.height, size_screen.width) :iPhone5?@"bg_568.png":@"bg.png"];
    [showView addSubview:backgroundImg];
    UIImageView *top= [self creatImageView:CGRectMake(0, 0, size_screen.height, 44) :iPhone5?@"nolink_4_568.png":@"nolink_4.png"];
    [showView addSubview:top];
    table=[[UITableView alloc]initWithFrame:CGRectMake(0, 44, size_screen.height, 320-64)];
    table.backgroundColor=[UIColor clearColor];
    table.delegate=self;table.dataSource=self;
    [showView addSubview:table];
    
    UIButton *goBackBut=[UIButton buttonWithType:UIButtonTypeCustom];
    [goBackBut addTarget:self action:@selector(backToBackView)
        forControlEvents:UIControlEventTouchUpInside];
    [goBackBut setBackgroundImage:[UIImage imageNamed:iPhone5?@"but3_568.png":@"but3.png"] forState:UIControlStateNormal];
    goBackBut.frame=CGRectMake(0, 0, (float)140*(size_screen.height/480), 44);
    [showView addSubview:goBackBut];
    //nameLable=[self creatLab:CGRectMake(size_screen.height-80, 10, 80, 34) :@""];
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (deviceName.length>0) {
        return 50;
    }
    return 0;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    dName.text=deviceName;
    return view;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    // Return the number of rows in the section.
    return appDelegate.peripherals.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return CellHeight;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.textLabel.font=[UIFont boldSystemFontOfSize:25];
        UILabel *lab=[[UILabel alloc]initWithFrame:CGRectMake(size_screen.height-120, 0, 80, CellHeight)];
        [cell addSubview:lab];
        lab.backgroundColor=[UIColor clearColor];
        //lab.tag=11;
        lab.font=cell.textLabel.font;
        lab.text=@"未连接";
    }
    
    CBPeripheral *savePeripheral=[appDelegate.peripherals objectAtIndex:indexPath.row];
    
    if (savePeripheral.name==nil) {
        cell.textLabel.text=@"unKnown";
    }
    else{
        cell.textLabel.text=savePeripheral.name;
    }
    cell.textLabel.textColor=[UIColor blackColor];
    
    
    //    cell.textLabel.text=@"1111";
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"确定连接此设备?" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定",@"取消",nil];
    [alert show];
    selectIndex=indexPath.row;
    [table reloadData];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (buttonIndex==0) {
        
        if (appDelegate.peripherals.count==0) {
            return;
        }
        [appDelegate connectSelectPer:selectIndex];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    // Return YES for supported orientations
    return (interfaceOrientation == UIDeviceOrientationLandscapeLeft);
}
//- (BOOL)shouldAutorotate
//{
//    return YES;
//}
//- (NSUInteger)supportedInterfaceOrientations
//{
//    return UIDeviceOrientationLandscapeLeft;
//}

@end
