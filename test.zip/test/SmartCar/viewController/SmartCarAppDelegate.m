//
//  SmartCarAppDelegate.m
//  SmartCar
//
//  Created by goopai on 13-3-21.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import "SmartCarAppDelegate.h"

#include "GSEvent.h"
#include "mouse_msgs.h"
#include "hid-support-internal.h"
#include "hid-support.h"
#import "SVProgressHUD.h"
#import "introViewController.h"
#import "Reachability.h"
#define KHeight 600
#define Kwidth 1024

Byte *bytes;
@interface UIApplication (Undocumented)
- (void) launchApplicationWithIdentifier: (NSString*)identifier suspended: (BOOL)suspended;
@end
@interface SpringBoard : UIApplication

-(int) activeInterfaceOrientation;
@end
@interface SBStatusBarController : UIApplication
-(int)statusBarOrientation;
@end
SpringBoard* sb;
SBStatusBarController *bar;
float CarWidth;
@implementation SmartCarAppDelegate
@synthesize savePeripheral,manager,peripherals,writeCharacteristic,smart;



- (void)locationMyCity
{
    locationManager = [[CLLocationManager alloc] init];//创建位置管理器
    locationManager.delegate=self;
    locationManager.desiredAccuracy=kCLLocationAccuracyBest;
    locationManager.distanceFilter=1000.0f;
    //启动位置更新
    [locationManager startUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
    // 获取当前所在的城市名
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *array, NSError *error)
     {
         if (array.count > 0)
         {
             CLPlacemark *placemark = [array objectAtIndex:0];
             NSString *city = placemark.locality;
             currentCity=city;
             NSMutableDictionary *dic=[[NSMutableDictionary alloc]init];
             NSString *sysName=[[UIDevice currentDevice]systemName];
             NSString *version=[[UIDevice currentDevice]systemVersion];
             NSString *curVer=[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
             NSString *identifer=[[UIDevice currentDevice]uniqueIdentifier];
             NSString *phoneModel=[self getMachine];
             NSString *connectCount=@"0";
             [dic setObject:city forKey:@"city"];
             [dic setObject:sysName forKey:@"phone_system"];
             [dic setObject:version forKey:@"system_version"];
             [dic setObject:curVer forKey:@"da_version"];
             [dic setObject:identifer forKey:@"imei"];
             [dic setObject:phoneModel forKey:@"phone_model"];
             [dic setObject:connectCount forKey:@"da_use"];
             [dic setObject:@"" forKey:@"vin"];
             [self sendCarInfo:[dic copy]];

            
         }
         else if (error == nil && [array count] == 0)
         {
             NSLog(@"No results were returned.");
         }
         else if (error != nil)
         {
             NSLog(@"An error occurred = %@", error);
         }
     }];
     [locationManager stopUpdatingLocation];
}
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self locationMyCity];
openM();
//    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, updateEnabled, CFSTR("com.apple.iokit.hid.displayStatus"), NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stateChange1) name:UIScreenDidConnectNotification object:nil];
[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stateChange2) name:UIScreenDidDisconnectNotification object:nil];
self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
introViewController *intro=[[introViewController alloc]init];

smart=[[SmartCarViewController alloc]init];
if (![[NSUserDefaults standardUserDefaults] objectForKey:@"first"]) {
    self.window.rootViewController=intro;
}
else{
    self.window.rootViewController=smart;
}

perUUID=[NSUserDefaults standardUserDefaults];
peripherals=[[NSMutableArray alloc]init];
btManager = [BluetoothManager sharedInstance];
sb = [UIApplication sharedApplication];

mouseOpen();
CGRect rect_screen = [[UIScreen mainScreen]bounds];
size_screen = rect_screen.size;
if (!iPhone5) {
    CarWidth=size_screen.height * (float)KHeight / size_screen.width;
    
}
else{
    CarWidth=Kwidth;
}

manager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()];
[self checkNetwork];
return YES;
}
static void updateEnabled(CFNotificationCenterRef center, void* observer, CFStringRef name, const void* object, CFDictionaryRef userInfo) {
uint64_t state;
int token;
notify_register_check("com.apple.iokit.hid.displayStatus", &token);
notify_get_state(token, &state);
notify_cancel(token);
sendIsLocked(state);
}

-(void)sendCarInfo:(NSDictionary *)dic{
[[Tools shardInstance] httpRequestJsonData:dic :@"http://www.zenway.com.cn/odb/userinfo.php"];
[Tools shardInstance].delegate=self;

}
-(void)httpRequestSuccess:(NSDictionary *)dic{
//NSLog(@"%@",dic);
if (((NSString *)[dic objectForKey:@"status"]).intValue==1) {
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"carInfo"];
}
else if(((NSString *)[dic objectForKey:@"status"]).intValue==0){
    if ([dic objectForKey:@"data"]==[NSNull null]) {
        return;
    }
    NSString *s=[dic objectForKey:@"data"];
    if (s.length>0) {
        count=[[dic objectForKey:@"data"]intValue];
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%d",count] forKey:@"count"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self getInfo];
    }
    
}
//NSLog(@"%@",[[NSUserDefaults standardUserDefaults]objectForKey:@"count"]);

}
- (void)checkNetwork
{
[[NSNotificationCenter defaultCenter] addObserver:self
                                         selector:@selector(reachabilityChanged:)
                                             name:kReachabilityChangedNotification
                                           object:nil];

Reachability * reach = [Reachability reachabilityWithHostname:@"www.google.com"];
[reach startNotifier];

}

-(void)reachabilityChanged:(NSNotification*)note
{
Reachability * reach = [note object];

if([reach isReachable])
{
    NSDictionary *dic=[[NSUserDefaults standardUserDefaults]objectForKey:@"carInfo"];
    //NSLog(@"%@信息",dic);
    [self sendCarInfo:dic];
    if (self.savePeripheral&&self.savePeripheral.isConnected) {
        [self sendForFeedback];
    }
}

}

-(void)checkIsconnected{
if (self.savePeripheral&&self.savePeripheral.isConnected) {
    
    [smart setConnect:savePeripheral.name];
}
else{
    [smart setConnect:nil];
}

}

-(void)stateChange1{
if (self.savePeripheral&&self.savePeripheral.isConnected) {
    [self sendForIsRuning];
}
[self scanPer];
}
-(void)stateChange2{
[smart checkIsRunning:NO];
[self stopScan];
[smart checkLink:NO :NO];
//[self homeButtonPressed];
}

-(NSString*)getMachine{
size_t size;
sysctlbyname("hw.machine", NULL, &size, NULL, 0);
char *name = malloc(size);
sysctlbyname("hw.machine", name, &size, NULL, 0);

NSString *machine = [NSString stringWithCString:name encoding:NSUTF8StringEncoding];
//NSLog(@"%@型号",machine);
free(name);


 if( [machine isEqualToString:@"iPhone4,1"] )
{
    if (saveByte==0x21) {
       machine = @"IPHONE4SNEW";
    }
    else if (saveByte==0x11){
         machine = @"IPHONE4S";
    }
    else if(saveByte==0x31){
    machine=@"IPHONE4SNEWB";
}
   
}
else
{
    if (saveByte==0x21) {
        machine = @"IPHONE5NEW";
    }
    else if (saveByte==0x11){
    machine = @"IPHONE5";
    }
    else if(saveByte==0x31){
        machine=@"IPHONE5NEWB";
    }

}
//( [machine isEqualToString:@"iPhone5,2"]|| [machine isEqualToString:@"iPhone5,1"])

return machine;
}

-(void)scanPer{
    if ([UIScreen screens].count==1) {
        return;
    }
if (self.savePeripheral&&self.savePeripheral.isConnected) {
    [smart setConnect:savePeripheral.name];
}
else{
    [smart setConnect:nil];
    [smart changePointAnimation];
}
[NSThread detachNewThreadSelector:@selector(blueScan) toTarget:self withObject:nil];
}
-(void)blueScan{
[manager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:@"ffe0"]] options:@{ CBCentralManagerScanOptionAllowDuplicatesKey : [NSNumber numberWithBool:YES] }];
}
-(void)stopScan{
[smart reSetTimer];
[manager stopScan];
}
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{

}

- (void) centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)aPeripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
//NSLog(@"%@设备",aPeripheral);
NSString *s=[perUUID objectForKey:@"saveUUID"];
if (s&&[s isEqualToString:aPeripheral.name]) {
    self.savePeripheral=aPeripheral;
    [central connectPeripheral:self.savePeripheral options:nil];
    
}
if (![peripherals containsObject:aPeripheral]) {
    [peripherals addObject:aPeripheral];
    [smart.table reloadData];
}


}
-(void)connectSelectPer:(int)index{
self.savePeripheral=[peripherals objectAtIndex:index];

if (!self.savePeripheral.isConnected) {
    [manager connectPeripheral:self.savePeripheral options:nil];
}

}
- (void) centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
self.savePeripheral=nil;
[smart setConnect:nil];
[Tools shardInstance].writeCharacteristic=nil;
[Tools shardInstance].savePeripheral=nil;
}
- (void) centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)aPeripheral
{

[aPeripheral setDelegate:self];
[aPeripheral discoverServices:nil];
[SVProgressHUD showSuccessWithStatus:@"蓝牙已连接"];
[[NSUserDefaults standardUserDefaults]setObject:aPeripheral.name forKey:@"saveUUID"];
[[NSUserDefaults standardUserDefaults] synchronize];
[smart setConnect:aPeripheral.name];
self.savePeripheral=aPeripheral;
if ([peripherals containsObject:aPeripheral]) {
    [peripherals removeObject:aPeripheral];
}
[self stopScan];
[smart.table reloadData];
[smart backToBackView];

}
- (void) centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
[self scanPer];
self.savePeripheral=nil;
[smart setConnect:nil];
[Tools shardInstance].writeCharacteristic=nil;
[Tools shardInstance].savePeripheral=nil;
}

-(void)getInfo{
count=[[[NSUserDefaults standardUserDefaults]objectForKey:@"count"]integerValue];
count++;
[[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%d",count] forKey:@"count"];
[[NSUserDefaults standardUserDefaults] synchronize];
NSMutableDictionary *dic=[[NSMutableDictionary alloc]init];
NSString *sysName=[[UIDevice currentDevice]systemName];
NSString *version=[[UIDevice currentDevice]systemVersion];
NSString *curVer=[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
NSString *identifer=[[UIDevice currentDevice]uniqueIdentifier];
NSString *phoneModel=[self getMachine];
NSString *connectCount=[NSString stringWithFormat:@"%d",count];
    if (currentCity) {
        [dic setObject:currentCity forKey:@"address"];
    }
    if (carInfo) {
        [dic setObject:carInfo forKey:@"car_info"];
    }
[dic setObject:sysName forKey:@"phone_system"];
[dic setObject:version forKey:@"system_version"];
[dic setObject:curVer forKey:@"da_version"];
[dic setObject:identifer forKey:@"imei"];
[dic setObject:phoneModel forKey:@"phone_model"];
[dic setObject:connectCount forKey:@"da_use"];
[dic setObject:@"" forKey:@"vin"];
Reachability *reach=[Reachability reachabilityWithHostname:@"www.google.com"];
if ([reach isReachable]) {
    
    [self sendCarInfo:[dic copy]];
}
else{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"carInfo"]) {
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"carInfo"];
    }
    [[NSUserDefaults standardUserDefaults]setObject:[dic copy] forKey:@"carInfo"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    //NSLog(@"%@存储",[[NSUserDefaults standardUserDefaults]objectForKey:@"carInfo"]);
}

}
- (void) peripheral:(CBPeripheral *)aPeripheral didDiscoverServices:(NSError *)error {

for (CBService *aService in aPeripheral.services){
    //NSLog(@"%@服务",aService.UUID);
    if ([aService.UUID isEqual:[CBUUID UUIDWithString:@"ffe0"]]) {
        [aPeripheral discoverCharacteristics:nil forService:aService];
    }
}
}

- (void) peripheral:(CBPeripheral *)aPeripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    for (CBCharacteristic *aChar in service.characteristics)
    {
        if (aChar.properties & CBCharacteristicPropertyNotify)
        {
            NSLog(@"999999");
            [aPeripheral setNotifyValue:YES forCharacteristic:aChar];
        }
        
        if (aChar.properties & CBCharacteristicPropertyWriteWithoutResponse || aChar.properties & CBCharacteristicPropertyWrite)
        {
            NSLog(@"888888");
            self.writeCharacteristic = aChar;
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
                
                [self sendIos];
            });
            [self performSelector:@selector(sendTime) withObject:nil afterDelay:2];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
                [self sendForFeedback];
            });
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
                [self sendForIsRuning];
            });
            
            [Tools shardInstance].writeCharacteristic=self.writeCharacteristic;
            [Tools shardInstance].savePeripheral=self.savePeripheral;

            
        }
    }

}

-(void)sendForCarInfo{
    Byte *b=(Byte *)malloc(4);
    b[0]=0x0b;b[1]=0x29;
    b[2]=0x00;b[3]=0x29;
    NSData *data =[[NSData alloc] initWithBytes:b length:4];
    [self perSend:data];

}

-(void)sendForIsRuning{
// NSLog(@"判断运行");
Byte *b=(Byte *)malloc(4);
b[0]=0x0b;b[1]=0x28;
b[2]=0x00;b[3]=0x28;
NSData *data =[[NSData alloc] initWithBytes:b length:4];
[self perSend:data];
}
-(void)sendForFeedback{
Byte *b=(Byte *)malloc(4);
b[0]=0x0b;b[1]=0x27;
b[2]=0x00;b[3]=0x27;
NSData *data =[[NSData alloc] initWithBytes:b length:4];
[self perSend:data];

}
-(void)perSend:(NSData *)data{
if (self.savePeripheral) {
    [self.savePeripheral writeValue:data forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithoutResponse];
}
}
void sendIsLocked (BOOL isLocked){
Byte *b=(Byte *)malloc(5);
b[0]=0x0b;b[1]=0x25;b[2]=0x01;b[3]=isLocked?2:1;
Byte sum=0x00;
for (int i=1; i<4; i++) {
    sum+=b[i];
    //NSLog(@"%0x",b[i]);
}
b[4]=sum;
NSData *data =[[NSData alloc] initWithBytes:b length:5];
[[Tools shardInstance] sendIsLocked:data];
}

-(void)sendData{
NSString *path=[NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@",[self getMachine]]];

NSFileManager *man=[NSFileManager defaultManager];
if ([man fileExistsAtPath:path]) {
    NSLog(@"exist");
    NSData *da1=[[NSData alloc]initWithContentsOfFile:path];
    bytes=(Byte*)[da1 bytes];
}
else{
    NSLog(@"notexist");
    NSData *data=[[NSData alloc]initWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.goopai.cn/iphone/%@",[self getMachine]]]];
    bytes=(Byte*)[data bytes];
    [data writeToFile:path atomically:YES];
}
if (bytes==nil) {
    return;
}
Byte *b=(Byte *)malloc(20);

for (int i=0; i<20; i++) {
    [self send:i andByte:b];
    
}

}
-(void)sendTime{
NSDate *date=[NSDate date];
NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
[formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
NSString *curTime=[formatter stringFromDate:date];
//NSLog(@"%@",curTime);
Byte *b=(Byte *)malloc(10);
int Y=[curTime substringWithRange:NSMakeRange(2, 2)].intValue;
int M=[curTime substringWithRange:NSMakeRange(5, 2)].intValue;
int D=[curTime substringWithRange:NSMakeRange(8, 2)].intValue;
int h=[curTime substringWithRange:NSMakeRange(11, 2)].intValue;
int m=[curTime substringWithRange:NSMakeRange(14, 2)].intValue;
int S=[curTime substringWithRange:NSMakeRange(17, 2)].intValue;
b[0]=0x0b;b[1]=0x26;
b[2]=0x06;b[3]=Y;
b[4]=M;b[5]=D;
b[6]=h;b[7]=m;
b[8]=S;
Byte sum = 0x00;
for (int i =1; i<9; i++) {
    sum += b[i];
     //NSLog(@"%0xTIME",b[i]);
}
b[9]=sum;
NSData *data =[[NSData alloc] initWithBytes:b length:10];

[self perSend:data];

}

-(void)sendIos{

NSString *ver=[UIDevice currentDevice].systemVersion;
// NSLog(@"%@版本",ver);
int L=[ver substringWithRange:NSMakeRange(0, 1)].intValue;
int M=[ver substringWithRange:NSMakeRange(2, 1)].intValue;
int R=ver.length>3?[ver substringWithRange:NSMakeRange(4, 1)].intValue:0;
// NSLog(@"%d%d%d",L,M,R);
Byte *b=(Byte *)malloc(8);

b[0]=0x0b;b[1]=0x17;
b[2]=0x04;b[3]=0x02;
b[4]=L;b[5]=M;
b[6]=R;
Byte sum = 0x00;

for (int i=1; i<7; i++) {
    sum += b[i];
    //NSLog(@"%0xIOS",b[i]);
}
b[7]=sum;
NSData *data =[[NSData alloc] initWithBytes:b length:8];
[self perSend:data];
}
-(void)send:(int)index andByte:(Byte*)by{

by[0]=0x0b;by[1]=0x21;by[2]=16;by[3]=index;
for (int i=4; i<19; i++) {
    by[i]=bytes[index*15+i-4];
    //NSLog(@"%0x数据index%d",by[i],index);
}
Byte *bb=0x00;
for (int i=1; i<19; i++) {
    bb+=by[i];
    
}
by[19]=bb;

NSData *data =[[NSData alloc] initWithBytes:by length:20];
[self perSend:data];
}

- (void) peripheral:(CBPeripheral *)aPeripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{

NSData * updatedValue = characteristic.value;
[self byteHandle:updatedValue];
}
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    //NSLog(@"%@发送数据",characteristic);
}
-(void)openSelf{
NSString *s=@"com.goopai.SmartCar";
[[UIApplication sharedApplication] launchApplicationWithIdentifier:s suspended:FALSE];
}
-(void)powerButtonPressed{
hid_inject_button_down(HWButtonLock);
hid_inject_button_up(HWButtonLock);
}
-(void)homeButtonPressed{
hid_inject_button_down(HWButtonHome);
hid_inject_button_up(HWButtonHome);
[self swipeReady];
//[self performSelector:@selector(swipe) withObject:nil afterDelay:1];
}
-(void)swipeReady{
sleep(1);
[self swipe];
}
- (int)getIntFromBytes:(Byte*) b int1:(int)startIndex int2:(int)size
{
int result = 0;
int endIndex = startIndex + size;
for(int i=startIndex;i<endIndex;i++)
{
    result = (result << 8 ) + b[i];
}
return result;
}
int lastInterval;
int interval1;
int interval2;
-(void)byteHandle:(NSData *)data{

testByte = (Byte *)[data bytes];
Byte sum = 0x00;

for (int i=1; i<data.length-1; i++) {
    sum += testByte[i];
    NSLog(@"%0x数据",testByte[i]);
}
switch (testByte[1]) {
    case 0x12:
    {
        if (sum==testByte[data.length-1]) {
            [NSThread detachNewThreadSelector:@selector(threadHandleRight) toTarget:self withObject:nil];
        }
        
    }
        break;
    case 0x13:
    {
        switch (testByte[3]) {
            case 0x01:
            {
                if (testByte[4]==0x01) {
                    interval1=[[NSDate date] timeIntervalSince1970];
                    hid_inject_button_down(HWButtonHome);
                }
                else{
                    hid_inject_button_up(HWButtonHome);
                    interval2=[[NSDate date] timeIntervalSince1970];
                    if (interval2-interval1>1) {
                        return;
                    }
                    if ([[NSDate date] timeIntervalSince1970]-lastInterval>1.6) {
                        [self performSelector:@selector(swipe) withObject:nil afterDelay:1];
                    }
                    else{
                        [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(swipe) object:nil];
                        
                    }
                    lastInterval=[[NSDate date] timeIntervalSince1970];
                    
                    
                }
                
            }
                break;
                                
            default:
                break;
        }
    }
        break;
    case 0x21:
    {
        NSString *path=[NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@",[self getMachine]]];
        
        NSFileManager *man=[NSFileManager defaultManager];
        if ([man fileExistsAtPath:path]) {
           // NSLog(@"exist");
            NSData *da1=[[NSData alloc]initWithContentsOfFile:path];
            bytes=(Byte*)[da1 bytes];
        }
        else{
            //NSLog(@"notexist");
            NSData *data=[[NSData alloc]initWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.goopai.cn/iphone/%@",[self getMachine]]]];
            bytes=(Byte*)[data bytes];
            //[data writeToFile:path atomically:YES];
        }
        
        // NSLog(@"请求数据%d",(int)testByte[3]);
        Byte *b=(Byte *)malloc(20);
        
        [self send:(int)testByte[3] andByte:b];
    }
        break;
    case 0x27:
    {
        
        saveByte=testByte[3];
        NSLog(@"%0xpppppppppp",saveByte);
        [self performSelector:@selector(sendData) withObject:nil afterDelay:0.1];
    }
        break;
    case 0x28:
    {
        //NSLog(@"%0x字节",testByte[3]);
        if (testByte[3]==0x00) {
            [smart checkIsRunning:NO];
            //NSLog(@"未运行");
        }
        else{
            [smart checkIsRunning:YES];
            //NSLog(@"运行");
        }
        
    }
        break;
    case 0x29:
    {
        //NSLog(@"%0x字节",testByte[3]);
        int num=(int)testByte[2];
        Byte b[num];
        for (int i=0; i<num; i++) {
            b[i]=testByte[i+3];
        }
        NSString *s=[[NSString alloc]initWithBytes:b length:(int)testByte[3] encoding:NSUTF8StringEncoding];
        carInfo=s;
        [self getInfo];
    }
        break;


    default:
        break;
}

}
-(void)swipe{
mouseSendEvent(235, 106, 1);
mouseSendEvent(235, 101, 1);
mouseSendEvent(235, 89, 1);
mouseSendEvent(235, 89, 0);
}
-(void)threadHandleRight{
[self pointManger:testByte x:4 y:6];
}
int saveOri=1;
-(void)handlePoint:(float)pointX Y:(float)pointY state:(int)state1{
int orientation = [sb   activeInterfaceOrientation];
int x=1035-pointX;
int y=590-pointY;
int state=state1;
if (orientation==5) {
    orientation=saveOri;
}
else{
    saveOri=orientation;
}
switch (orientation) {
    case 1: //0度
    {
        x=(float)(x-(Kwidth- size_screen.width * (float)KHeight/size_screen.height)/2) *
        (float)size_screen.height/KHeight;
        y=y*(float)size_screen.height/KHeight;
        
    }
        break;
    case 2: //180度
    {
        x=size_screen.width-(float)(x-(Kwidth-size_screen.width*(float)KHeight/size_screen.height)/2)*(float)size_screen.height/KHeight;
        y=size_screen.height-y*(float)size_screen.height/KHeight;
        
        
    }
        break;
        
    case 3:
    {
        int a=(float)(  x- ( Kwidth-CarWidth) /2 )*(float)size_screen.width/KHeight;
        
        int b=y*(float)size_screen.width/KHeight;
        x=size_screen.width-b;
        y=a;
        
        
        
    }
        break;
        
    case 4:
    {
        int a=(float)(x- ( Kwidth-CarWidth) /2 )*(float)size_screen.width/KHeight;
        
        int b=y*(float)size_screen.width/KHeight;
        x=b;
        y=size_screen.height- a;
        
    }
        break;
        
        
    default:
        break;
}
if (y>size_screen.height) {
    if (x>0&&x<size_screen.width) {
        mouseSendEvent(x, size_screen.height, 0);
    }
    return;
}
if (y<0) {
    if (x>0&&x<size_screen.width) {
        mouseSendEvent(x, 0, 0);
    }
    return;
    
}

if (x<0) {
    if (y>0&&y<size_screen.height) {
        mouseSendEvent(0, y, 0);
    }
    return;
}

if (x>size_screen.width) {
    if (y>0&&y<size_screen.height) {
        mouseSendEvent(size_screen.width, y, 0);
    }
    return;
}

mouseSendEvent(x, y, state);
}

-(void)pointManger:(Byte *)testByte1 x:(int)startX y:(int)startY
{
float x=[self getIntFromBytes:testByte1 int1:startX int2:2];
float y=[self getIntFromBytes:testByte1 int1:startY int2:2];
int state=(int)testByte1[3];
[self handlePoint:x Y:y state:state];

}

- (void)applicationWillResignActive:(UIApplication *)application
{
//[manager stopScan];

[peripherals removeAllObjects];
[smart.table reloadData];
[self stopScan];
[self applicationDidEnterBackground:application];
// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
//        UIApplication*   app = [UIApplication sharedApplication];
//        __block    UIBackgroundTaskIdentifier bgTask;
//    
//        bgTask = [app beginBackgroundTaskWithExpirationHandler:^{
//    
//    
//            dispatch_async(dispatch_get_main_queue(), ^{
//                if (bgTask != UIBackgroundTaskInvalid)
//                {
//                    bgTask = UIBackgroundTaskInvalid;
//                }
//            });
//        }];
//    
//    
//        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//            dispatch_async(dispatch_get_main_queue(), ^{
//                if (bgTask != UIBackgroundTaskInvalid)
//                {
//                    bgTask = UIBackgroundTaskInvalid;
//                }
//            });
//        });
//[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(go) name:@"a" object:nil];
//[[NSNotificationCenter defaultCenter]postNotificationName:￼ object:￼];
// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.

}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
saveByte=0x11;
[btManager setPowered:YES];
[self checkIsconnected];
if ([[NSUserDefaults standardUserDefaults] objectForKey:@"first"]) {
    [self performSelector:@selector(scanPer) withObject:nil afterDelay:1.0];
}
if (self.savePeripheral&&self.savePeripheral.isConnected) {
    [self sendForIsRuning];
}
// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{

// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
//#import <BluetoothManager/BluetoothManager.h>
