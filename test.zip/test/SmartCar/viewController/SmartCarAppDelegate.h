//
//  SmartCarAppDelegate.h
//  SmartCar
//
//  Created by goopai on 13-3-21.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <UIKit/UIScreen.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <BluetoothManager/BluetoothManager.h>
#import "SmartCarViewController.h"
#import "Tools.h"
#import <CoreLocation/CoreLocation.h>
@interface SmartCarAppDelegate : UIResponder <UIApplicationDelegate,CBCentralManagerDelegate,CBPeripheralDelegate,netWorkDelegate,CLLocationManagerDelegate>
{
     CLLocationManager *locationManager;
    SmartCarViewController *smart;
    NSMutableArray *peripherals;
    //SettingViewController *set;
    NSOperationQueue *aq;
    int length;
    Byte *testByte;
    CGSize size_screen;
    CBCentralManager *manager;
    CBPeripheral *savePeripheral;
    BluetoothManager *btManager;
    CBCharacteristic *writeCharacteristic;
    NSUserDefaults *perUUID;
    Byte saveByte;
    int count;
    NSString *carInfo;
    NSString *currentCity;
}
@property(nonatomic,strong)SmartCarViewController *smart;
@property(nonatomic,strong)CBCharacteristic *writeCharacteristic;
@property(nonatomic,strong)NSMutableArray *peripherals;
@property(nonatomic,strong)CBCentralManager *manager;
@property(retain)CBPeripheral *savePeripheral;
@property (strong, nonatomic) UIWindow *window;
-(void)connectSelectPer:(int)index;
 -(void)scanPer;   
-(void)stopScan;
-(void)homeButtonPressed;
-(void)checkIsconnected;
-(void)swipe;
-(void)swipeReady;
@end
