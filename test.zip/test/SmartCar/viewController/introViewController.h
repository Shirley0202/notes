//
//  introViewController.h
//  SmartCar
//
//  Created by goopai ios on 13-6-25.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cusPage.h"
@interface introViewController : UIViewController<UIScrollViewDelegate>
{
    CGSize size_screen;
    cusPage *page;
    UIScrollView *sc;
}
@end
