//
//  introViewController.m
//  SmartCar
//
//  Created by goopai ios on 13-6-25.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import "introViewController.h"
#import "SmartCarViewController.h"
#import "SmartCarAppDelegate.h"

@interface introViewController ()

@end

@implementation introViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    CGRect rect_screen = [[UIScreen mainScreen]bounds];
    size_screen = rect_screen.size;
	sc=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, size_screen.height, 300)];
    sc.pagingEnabled=YES;
    sc.delegate=self;
    sc.showsHorizontalScrollIndicator=NO;
    [self.view addSubview:sc];
    sc.contentSize=CGSizeMake(size_screen.height*3, 300);
    for (int i=0; i<3; i++) {
        UIImageView *img=[[UIImageView alloc]initWithFrame:CGRectMake(size_screen.height*i, 0, size_screen.height, 300)];
        [sc addSubview:img];
        if (iPhone5) {
            img.image=[UIImage imageNamed:[NSString stringWithFormat:@"y%d_568.png",i+1]];
        }
        else{
            img.image=[UIImage imageNamed:[NSString stringWithFormat:@"y%d.png",i+1]];
        }
        
    }
    page=[[cusPage alloc]init];
    page.frame=CGRectMake(0, 270, size_screen.width, 30);
    //NSLog(@"%f宽带",size_screen.width);
    [self.view addSubview:page];
    page.numberOfPages=3;
    page.currentPage=0;
     [page addTarget:self action:@selector(changePage:)forControlEvents:UIControlEventValueChanged];
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    if (iPhone5) {
        [btn setBackgroundImage:[UIImage imageNamed:@"but1_0_568.png"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"but1_1_568.png"] forState:UIControlStateHighlighted];
         btn.frame=CGRectMake((size_screen.height-180)/2+size_screen.height*2, 240, 180, 34);
    }
    else{
        [btn setBackgroundImage:[UIImage imageNamed:@"but1_0.png"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"but1_1.png"] forState:UIControlStateHighlighted];
         btn.frame=CGRectMake((size_screen.height-160)/2+size_screen.height*2, 240, 160, 34);
    }
    
   
    [btn addTarget:self action:@selector(goStart) forControlEvents:UIControlEventTouchUpInside];
    [sc addSubview:btn];
}
-(void)goStart{
    //SmartCarViewController *smart=[[SmartCarViewController alloc]init];
    SmartCarAppDelegate* appDelegate=(SmartCarAppDelegate *)[UIApplication sharedApplication].delegate;
    [self presentViewController:appDelegate.smart animated:YES completion:^{
        
    }];
    [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:@"first"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
}
-(void)changePage:(UIPageControl*)sender{
    [page setCurrentPage:page.currentPage];
    [UIView animateWithDuration:0.3 animations:^{
        sc.contentOffset=CGPointMake(size_screen.height*sender.currentPage, 0);
    }];
    
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    int pageNum = (floor(scrollView.contentOffset.x / size_screen.height));
    
    page.currentPage = pageNum;
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    // Return YES for supported orientations
    return (interfaceOrientation == UIDeviceOrientationLandscapeLeft);
}
//- (BOOL)shouldAutorotate
//{
//    return YES;
//}
//- (NSUInteger)supportedInterfaceOrientations
//{
//    return UIDeviceOrientationLandscapeLeft;
//}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
