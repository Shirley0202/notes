//
//  cusPage.m
//  SmartCar
//
//  Created by goopai ios on 13-6-25.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import "cusPage.h"

@implementation cusPage

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _activeImage= [UIImage
                       imageNamed:@"doc_1.png"];
        _inactiveImage= [UIImage imageNamed:@"doc_0.png"];
    }
    return self;
}
- (void)updateDots
{
    for(int i = 0; i< [self.subviews count]; i++) {
        UIImageView* dot = [self.subviews objectAtIndex:i];
        [dot setFrame:CGRectMake(dot.frame.origin.x, dot.frame.origin.y,
                                     12,12)];
        if(i == self.currentPage){
            dot.image= _activeImage;
        }
        else
            dot.image= _inactiveImage;
    }
}

- (void)setCurrentPage:(NSInteger)currentPage
{
    [super setCurrentPage:currentPage];
    [self updateDots];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
