//
//  Tools.m
//  SmartCar
//
//  Created by goopai ios on 13-7-10.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//

#import "Tools.h"

@implementation Tools
@synthesize savePeripheral,writeCharacteristic,delegate;
+(Tools *)shardInstance{
    static dispatch_once_t once;
    static Tools *shaerd;
    dispatch_once(&once, ^{
        shaerd=[[Tools alloc]init];
    });
    return shaerd;
}
-(void)httpRequestJsonData:(NSDictionary *)param :(NSString *)url
{
    NSURL *baseURL = [NSURL URLWithString:url];
    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:baseURL];
    NSMutableURLRequest *request =[httpClient requestWithMethod:@"GET" path:url parameters:param];
    AFJSONRequestOperation *operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request
                                                                                        success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON)
                                         {
                                             NSDictionary *jsonDict = (NSDictionary *) JSON;
                                             if([delegate respondsToSelector:@selector(httpRequestSuccess:)])
                                             {
                                                 [delegate httpRequestSuccess:jsonDict];
                                             }
                                         }
                                         
                                                                                        failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON)
                                         {
                                             NSLog(@"Request Failure Because %@",[error description]);
                                             [self showErrorMessage];
                                         }];
    
    [AFJSONRequestOperation addAcceptableContentTypes:[NSSet setWithObject:@"text/html"]];
    
    [operation start];    
}
-(void)showErrorMessage{
   //[SVProgressHUD showErrorWithStatus:@"上传失败!"];
}
-(void)sendIsLocked:(NSData *)data{
    //NSLog(@"%@",savePeripheral);
    if (savePeripheral) {
        [savePeripheral writeValue:data forCharacteristic:writeCharacteristic type:CBCharacteristicWriteWithoutResponse];
        NSLog(@"%d数据",data.length);
    }

}
@end
