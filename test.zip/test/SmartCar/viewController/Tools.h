//
//  Tools.h
//  SmartCar
//
//  Created by goopai ios on 13-7-10.
//  Copyright (c) 2013年 www.goopai.cn. All rights reserved.
//
@protocol netWorkDelegate <NSObject>

-(void)httpRequestSuccess:(NSDictionary *)dic;
@end
#import <Foundation/Foundation.h>
#import "SmartCarAppDelegate.h"
#import "AFNetworking.h"
#import "SVProgressHUD.h"
@interface Tools : NSObject
{
    id<netWorkDelegate> delegate;
}
@property(nonatomic,strong)id<netWorkDelegate> delegate;
@property(nonatomic,strong)CBPeripheral *savePeripheral;
@property(nonatomic,strong)CBCharacteristic *writeCharacteristic;
+(Tools *)shardInstance;
-(void)sendIsLocked:(NSData *)data;
-(void)httpRequestJsonData:(NSDictionary *)param :(NSString *)url;
@end
