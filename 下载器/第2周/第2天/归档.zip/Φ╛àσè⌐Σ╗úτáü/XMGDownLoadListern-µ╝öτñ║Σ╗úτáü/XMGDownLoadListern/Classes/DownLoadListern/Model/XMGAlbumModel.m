//
//  XMGAlbumModel.m
//  XMGDownLoadListern
//
//  Created by 王顺子 on 16/11/25.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGAlbumModel.h"

@implementation XMGAlbumModel

@end
