//
//  XMGDownLoadTrackTVC.h
//  XMGFMDownLoadListern
//
//  Created by 王顺子 on 16/11/20.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGDownLoadBaseListTVC.h"

@interface XMGDownLoadTrackTVC : XMGDownLoadBaseListTVC

@end
