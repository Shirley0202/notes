//
//  XMGDownLoadedVoicInAlbumTVC.h
//  XMGDownLoadListern
//
//  Created by 王顺子 on 16/11/25.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGDownLoadBaseListTVC.h"

@interface XMGDownLoadedVoicInAlbumTVC : XMGDownLoadBaseListTVC

@property (nonatomic, assign) NSInteger albumID;

@end
