//
//  NSString+XMGMD5.h
//  XMGDownLoad
//
//  Created by 王顺子 on 16/11/17.
//  Copyright © 2016年 王顺子. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XMGMD5)

- (NSString *)MD5Str;

@end
