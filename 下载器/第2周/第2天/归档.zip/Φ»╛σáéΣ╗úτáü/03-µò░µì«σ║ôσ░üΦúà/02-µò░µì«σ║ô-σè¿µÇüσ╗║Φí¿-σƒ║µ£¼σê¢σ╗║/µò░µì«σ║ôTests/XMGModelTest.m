//
//  XMGModelTest.m
//  数据库
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "XMGModel.h"

@interface XMGModelTest : XCTestCase

@end

@implementation XMGModelTest

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    
//    [XMGModel modelIvarNameAndIvarType:NSClassFromString(@"XMGStu")];

    [XMGModel modelIvarNameAndSqliteType:NSClassFromString(@"XMGStu")];

}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
