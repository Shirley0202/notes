//
//  XMGStu.m
//  数据库
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGStu.h"

@implementation XMGStu


+ (NSString *)primaryKey {
    return @"stu_id";
}
@end
