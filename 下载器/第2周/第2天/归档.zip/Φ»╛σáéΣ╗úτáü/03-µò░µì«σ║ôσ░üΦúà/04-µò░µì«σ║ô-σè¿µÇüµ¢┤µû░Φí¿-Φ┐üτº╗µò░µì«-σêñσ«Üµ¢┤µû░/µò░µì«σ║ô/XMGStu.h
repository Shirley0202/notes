//
//  XMGStu.h
//  数据库
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMGSqliteModelProtocol.h"

@interface XMGStu : NSObject <XMGSqliteModelProtocol>

@property (nonatomic, assign, readonly) NSInteger stu_id;
@property (nonatomic, assign) double score;
@property (nonatomic, copy) NSString *name;

//@property (nonatomic, assign) double score3;

@end
