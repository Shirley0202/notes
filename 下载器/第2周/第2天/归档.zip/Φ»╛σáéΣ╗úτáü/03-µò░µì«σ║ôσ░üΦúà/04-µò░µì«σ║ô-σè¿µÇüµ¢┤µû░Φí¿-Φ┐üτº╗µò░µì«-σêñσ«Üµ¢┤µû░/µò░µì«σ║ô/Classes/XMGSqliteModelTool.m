//
//  XMGSqliteModelTool.m
//  数据库
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGSqliteModelTool.h"
#import "XMGSqliteTool.h"
#import "XMGModel.h"
#import "XMGTable.h"



@implementation XMGSqliteModelTool

+ (BOOL)saveModel:(id)model uid:(NSString *)uid {
    // 0. 判断是否存在这个表格, 如果不存在 根据这个模型创建一个表格
    // 1. 判断表格是否需要更新, 如果需要, 你更新表格
    
    // 2. 表格肯定有, 而且,最新
    // 3. 写入模型数据到表格里面
    
    return YES;
}


+ (BOOL)createTable:(Class)modelClass uid:(NSString *)uid {
    
    NSString *tableName = [XMGModel tableName:modelClass];
    
    NSString *nameTypeStr = [XMGModel modelIvarNameAndSqliteTypeStr:modelClass];

    if (![modelClass respondsToSelector:@selector(primaryKey)]) {
        NSLog(@"如果想要使用这个框架, 操作你的模型, 必须要实现+ (NSString *)primaryKey;");
        return NO;
    }
    
    NSString *primaryKey = [modelClass primaryKey];
    
     NSString *sql = [NSString stringWithFormat:@"create table if not exists %@(%@,primary key(%@))", tableName, nameTypeStr, primaryKey];
    
//    "create table 表名(字段名 字段类型 , 字段2名 字段类型, primary key(主键))";
    
    return [XMGSqliteTool dealWithSql:sql uid:uid];
    
    
}

+ (BOOL)isTableRequiredUpdate:(Class)cls uid:(NSString *)uid {
    
    // 1. 获取 模型里面的字段数组
    NSArray *array1 = [XMGModel modelIvarSortedNames:cls];
    
    // 2. 获取 表格里面所有的字段数组
    NSArray *array2 = [XMGTable columnSortedNames:[XMGModel tableName:cls] uid:uid];
    
    // 3. 比较
    return ![array1 isEqualToArray:array2];

}



@end
