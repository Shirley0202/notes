//
//  XMGSqliteModelTool.h
//  数据库
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMGSqliteModelProtocol.h"

@interface XMGSqliteModelTool : NSObject

+ (BOOL)saveModel:(id)model uid:(NSString *)uid;

+ (BOOL)createTable:(Class)modelClass uid:(NSString *)uid;

+ (BOOL)isTableRequiredUpdate:(Class)cls uid:(NSString *)uid;


@end
