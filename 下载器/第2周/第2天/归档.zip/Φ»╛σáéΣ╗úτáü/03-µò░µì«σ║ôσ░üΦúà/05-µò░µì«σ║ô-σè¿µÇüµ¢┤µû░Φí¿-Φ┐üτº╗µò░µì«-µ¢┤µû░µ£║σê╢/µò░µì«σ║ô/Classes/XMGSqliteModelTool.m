//
//  XMGSqliteModelTool.m
//  数据库
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGSqliteModelTool.h"
#import "XMGSqliteTool.h"
#import "XMGModel.h"
#import "XMGTable.h"



@implementation XMGSqliteModelTool

+ (BOOL)saveModel:(id)model uid:(NSString *)uid {
    // 0. 判断是否存在这个表格, 如果不存在 根据这个模型创建一个表格
    // 1. 判断表格是否需要更新, 如果需要, 你更新表格
    
    // 2. 表格肯定有, 而且,最新
    // 3. 写入模型数据到表格里面
    
    return YES;
}


+ (BOOL)createTable:(Class)modelClass uid:(NSString *)uid {
    
    NSString *tableName = [XMGModel tableName:modelClass];
    
    NSString *nameTypeStr = [XMGModel modelIvarNameAndSqliteTypeStr:modelClass];

    if (![modelClass respondsToSelector:@selector(primaryKey)]) {
        NSLog(@"如果想要使用这个框架, 操作你的模型, 必须要实现+ (NSString *)primaryKey;");
        return NO;
    }
    
    NSString *primaryKey = [modelClass primaryKey];
    
     NSString *sql = [NSString stringWithFormat:@"create table if not exists %@(%@,primary key(%@))", tableName, nameTypeStr, primaryKey];
    
//    "create table 表名(字段名 字段类型 , 字段2名 字段类型, primary key(主键))";
    
    return [XMGSqliteTool dealWithSql:sql uid:uid];

}

+ (BOOL)isTableRequiredUpdate:(Class)cls uid:(NSString *)uid {
    
    // 1. 获取 模型里面的字段数组
    NSArray *array1 = [XMGModel modelIvarSortedNames:cls];
    
    // 2. 获取 表格里面所有的字段数组
    NSArray *array2 = [XMGTable columnSortedNames:[XMGModel tableName:cls] uid:uid];
    
    // 3. 比较
    return ![array1 isEqualToArray:array2];

}

+ (BOOL)updateTable:(Class)cls uid:(NSString *)uid {
    
    
    NSMutableArray *sqls = [NSMutableArray array];
    
    // 1. 创建一个临时表格(表格结构,肯定是最正确)
    NSString *tmpTableName = [XMGModel tmpTableName:cls];
    NSString *oldTableName = [XMGModel tableName:cls];
    
    NSString *nameTypeStr = [XMGModel modelIvarNameAndSqliteTypeStr:cls];
    
    if (![cls respondsToSelector:@selector(primaryKey)]) {
        NSLog(@"如果想要使用这个框架, 操作你的模型, 必须要实现+ (NSString *)primaryKey;");
        return NO;
    }
    
    NSString *primaryKey = [cls primaryKey];
    
    NSString *sql = [NSString stringWithFormat:@"create table if not exists %@(%@,primary key(%@));", tmpTableName, nameTypeStr, primaryKey];
    [sqls addObject:sql];
    //    "create table 表名(字段名 字段类型 , 字段2名 字段类型, primary key(主键))";

    
    // 2. 从旧表里面, 把数据 -> 临时表格
    // 2.1 应该按照主键, 插入数据到临时表
    // insert into xmgstu_tmp(stu_id) select stu_id from xmgstu;
    // insert into 临时表格名称(主键) select 主键 from 旧的表格;
    
    NSString *insertSql = [NSString stringWithFormat:@"insert into %@(%@) select %@ from %@;", tmpTableName, primaryKey, primaryKey, oldTableName];
    [sqls addObject:insertSql];
    
    
    NSArray *newColumnNames = [XMGModel modelIvarSortedNames:cls];
    NSArray *oldColumnNames = [XMGTable columnSortedNames:oldTableName uid:uid];
    for (NSString *newColumnName in newColumnNames) {
        // 2.2 根据主键, 旧的表格里面更新数据到 临时表格
        // update xmgstu_tmp set name = (select name from xmgstu where xmgstu.stu_id = xmgstu_tmp.stu_id);
        // update 临时表格名称 set 新字段名称 = (select 旧的字段名称 from 旧的表格 where 旧的表格.主键 = 临时表格名称.主键);
        if (![oldColumnNames containsObject:newColumnName]) {
            continue;
        }
        
        NSString *updateDataSQL = [NSString stringWithFormat:@"update %@ set %@ = (select %@ from %@ where %@.%@ = %@.%@);", tmpTableName, newColumnName, newColumnName, oldTableName, oldTableName, primaryKey, tmpTableName, primaryKey];
        [sqls addObject:updateDataSQL];
        
    }

    // 3. 删除旧表格
    NSString *deleteSql = [NSString stringWithFormat:@"drop table if exists %@;", oldTableName];
    [sqls addObject:deleteSql];
    
    // 4. 更新临时表格名称 xmgstu
    NSString *renameTable = [NSString stringWithFormat:@"alter table %@ rename to %@;", tmpTableName, oldTableName];
    [sqls addObject:renameTable];
    
//    NSLog(@"%@", sqls);
    
    [XMGSqliteTool dealWithSqls:sqls uid:uid];
    
    
    return YES;
}



@end
