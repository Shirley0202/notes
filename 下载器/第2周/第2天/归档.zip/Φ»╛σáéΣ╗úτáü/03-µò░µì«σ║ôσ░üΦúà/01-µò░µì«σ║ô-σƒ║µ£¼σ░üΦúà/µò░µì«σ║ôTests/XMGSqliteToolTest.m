//
//  XMGSqliteToolTest.m
//  数据库
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "XMGSqliteTool.h"

@interface XMGSqliteToolTest : XCTestCase

@end

@implementation XMGSqliteToolTest


- (void)testExample {
    
    [XMGSqliteTool dealWithSql:@"create table if not exists t_stu(id integer primary key autoincrement, name text, age real);" uid:nil];

}


- (void)testQuery {
    
    NSArray *array = [XMGSqliteTool querySql:@"select * from t_stu" uid:nil];
    NSLog(@"%@", array);
    
}


@end
