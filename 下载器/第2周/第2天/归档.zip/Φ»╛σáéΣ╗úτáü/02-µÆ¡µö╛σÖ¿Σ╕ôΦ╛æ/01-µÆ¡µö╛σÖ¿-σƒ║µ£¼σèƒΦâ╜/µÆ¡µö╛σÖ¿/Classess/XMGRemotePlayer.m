//
//  XMGRemotePlayer.m
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGRemotePlayer.h"
#import <AVFoundation/AVFoundation.h>

@interface XMGRemotePlayer ()

@property (nonatomic, strong) AVPlayer *player;

@end


@implementation XMGRemotePlayer

static XMGRemotePlayer *_shareInstance;

+ (instancetype)shareInstance {
    if (!_shareInstance) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _shareInstance = [[self alloc] init];
        });

    }
    return _shareInstance;
}


- (void)playWithUrl:(NSURL *)url {
    
    
    // 播放器对象
    // 内部封装了三个步骤
    //    AVPlayer *player = [AVPlayer playerWithURL:url];
    // 1. 资源的请求
    AVURLAsset *asset = [AVURLAsset assetWithURL:url];
    // 2. 资源的组织
     AVPlayerItem *item = [AVPlayerItem playerItemWithAsset:asset];
    [item addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    // 3. 资源的播放
    self.player = [AVPlayer playerWithPlayerItem:item];

    // 一定要注意, 一般不是直接去调用
//    [player play];
    
   
}


- (void)pause {
    [self.player pause];
}

- (void)resume {
    [self.player play];
}

- (void)stop {
    [self.player pause];
    [self.player.currentItem removeObserver:self forKeyPath:@"status"];
    self.player = nil;
}

// 15
- (void)seekWithTimeInterval:(NSTimeInterval)timeInterval {
    
    
    
    
//    CMTime 影片时间
    // 影片时间-> 秒
    //CMTimeGetSeconds(<#CMTime time#>);
    // 秒 -> 影片时间
    //CMTimeMake(秒, NSEC_PER_SEC)
    
    // 1. 获取当前播放时间 + 15
    NSTimeInterval sec = CMTimeGetSeconds(self.player.currentItem.currentTime) + timeInterval;
    
    [self.player seekToTime:CMTimeMake(sec, NSEC_PER_SEC) completionHandler:^(BOOL finished) {
        if (finished) {
            NSLog(@"确定加载这个时间段的资源");
        }else {
             NSLog(@"取消加载这个时间段的资源");
        }
    }];
    
}

- (void)seekToProgress:(float)progress {
    
    NSTimeInterval sec = CMTimeGetSeconds(self.player.currentItem.duration) * progress;
    
    [self.player seekToTime:CMTimeMakeWithSeconds(sec, NSEC_PER_SEC) completionHandler:^(BOOL finished) {
        if (finished) {
            NSLog(@"确定加载这个时间段的资源");
        }else {
            NSLog(@"取消加载这个时间段的资源");
        }
    }];

    
    
}

- (void)setRate:(float)rate {
    self.player.rate = rate;
}

- (void)setMuted:(BOOL)muted {
    self.player.muted = muted;
}

- (void)setVolume:(float)volume {
    if (volume > 0.0) {
        self.muted = NO;
    }
    [self.player setVolume:volume];
}


//@property (nonatomic, assign) float rate;
//@property (nonatomic, assign) BOOL muted;
//@property (nonatomic, assign) float volume;





- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    if([keyPath isEqualToString:@"status"]) {
       AVPlayerItemStatus status =  [change[NSKeyValueChangeNewKey] integerValue];
        
        switch (status) {
            case AVPlayerItemStatusUnknown:
            {
                NSLog(@"资源无效");
                break;
            }
            case AVPlayerItemStatusReadyToPlay:
            {
                NSLog(@"资源准备好了, 已经可以播放");
                [self.player play];
                break;
            }
            case AVPlayerItemStatusFailed:
            {
                NSLog(@"资源加载失败");
                break;
            }
                
            default:
                break;
        }
        
    }
    
    
}



@end
