//
//  ViewController.m
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "ViewController.h"
#import "XMGRemotePlayer.h"

@interface ViewController ()

@end

@implementation ViewController


- (IBAction)play:(id)sender {
    NSURL *url = [NSURL URLWithString:@"http://audio.xmcdn.com/group22/M0B/60/85/wKgJM1g1g0ShoPalAJiI5nj3-yY200.m4a"];
    [[XMGRemotePlayer shareInstance] playWithUrl:url];
}

- (IBAction)pause:(id)sender {
    [[XMGRemotePlayer shareInstance] pause];
}
- (IBAction)resume:(id)sender {
    [[XMGRemotePlayer shareInstance] resume];
}

- (IBAction)stop:(id)sender {
    [[XMGRemotePlayer shareInstance] stop];
}


- (IBAction)kuaijin15:(id)sender {
    [[XMGRemotePlayer shareInstance] seekWithTimeInterval:15];
}

- (IBAction)progress:(UISlider *)sender {
    [[XMGRemotePlayer shareInstance] seekToProgress:sender.value];
}
- (IBAction)doubleRate:(id)sender {
    [XMGRemotePlayer shareInstance].rate = 2.0;
}
- (IBAction)volume:(UISlider *)sender {
    [XMGRemotePlayer shareInstance].volume = sender.value;
}
- (IBAction)mute:(id)sender {
    [XMGRemotePlayer shareInstance].muted = ![XMGRemotePlayer shareInstance].muted;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}



@end
