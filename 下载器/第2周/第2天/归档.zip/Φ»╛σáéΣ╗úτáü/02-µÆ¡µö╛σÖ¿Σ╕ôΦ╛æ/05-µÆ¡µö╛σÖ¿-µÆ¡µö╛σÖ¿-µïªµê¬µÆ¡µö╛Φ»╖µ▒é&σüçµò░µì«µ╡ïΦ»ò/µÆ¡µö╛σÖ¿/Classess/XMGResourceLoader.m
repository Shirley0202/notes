//
//  XMGResourceLoader.m
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGResourceLoader.h"

@implementation XMGResourceLoader


- (BOOL)resourceLoader:(AVAssetResourceLoader *)resourceLoader shouldWaitForLoadingOfRequestedResource:(AVAssetResourceLoadingRequest *)loadingRequest  {
    
    NSLog(@"%@", loadingRequest);
    
    // 1. 搞数据
    NSData *data = [NSData dataWithContentsOfFile:@"/Users/seemygo/Desktop/123.mp3" options:NSDataReadingMappedIfSafe error:nil];
    
    // 2. 把数据传递给外界(资源的组织者-> 播放器)
    loadingRequest.contentInformationRequest.contentType = @"public.mp3";
    loadingRequest.contentInformationRequest.contentLength = 4702459;
    loadingRequest.contentInformationRequest.byteRangeAccessSupported = YES;
    
    long long requestOffset = loadingRequest.dataRequest.requestedOffset;
    long long requestLength = loadingRequest.dataRequest.requestedLength;
    
    NSData *subData = [data subdataWithRange:NSMakeRange(requestOffset, requestLength)];
    
    [loadingRequest.dataRequest respondWithData:subData];
    [loadingRequest finishLoading];

    return YES;

}

@end
