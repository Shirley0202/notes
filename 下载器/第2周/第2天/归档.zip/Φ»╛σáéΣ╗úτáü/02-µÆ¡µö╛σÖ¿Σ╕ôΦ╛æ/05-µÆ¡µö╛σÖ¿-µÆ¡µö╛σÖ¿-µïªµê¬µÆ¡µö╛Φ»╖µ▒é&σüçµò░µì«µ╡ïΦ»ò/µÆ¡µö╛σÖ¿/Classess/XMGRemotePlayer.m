//
//  XMGRemotePlayer.m
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGRemotePlayer.h"
#import <AVFoundation/AVFoundation.h>
#import "XMGResourceLoader.h"
#import "NSURL+Custom.h"

@interface XMGRemotePlayer ()
{
    BOOL _isUserPause;
}
@property (nonatomic, strong) AVPlayer *player;

@property (nonatomic, strong) XMGResourceLoader *loader;

@end


@implementation XMGRemotePlayer

static XMGRemotePlayer *_shareInstance;

+ (instancetype)shareInstance {
    if (!_shareInstance) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _shareInstance = [[self alloc] init];
        });

    }
    return _shareInstance;
}


- (void)playWithUrl:(NSURL *)url isCache:(BOOL)isCache {
    
    
//    XMGRemoteAudioPlayerStateUnknown = 0,
//    XMGRemoteAudioPlayerStateLoading   = 1,
//    XMGRemoteAudioPlayerStatePlaying   = 2,
//    XMGRemoteAudioPlayerStateStopped   = 3,
//    XMGRemoteAudioPlayerStatePause     = 4,
//    XMGRemoteAudioPlayerStateFailed    = 5
    if ([url isEqual:self.url]) {
        // 播放器存在, 判断状态
        if (self.state == XMGRemoteAudioPlayerStateLoading) {
            
              return;
        }
        if (self.state == XMGRemoteAudioPlayerStatePlaying) {
            
            return;
        }
//        if (self.state == XMGRemoteAudioPlayerStateStopped) {
//            
//            
//        }
        if (self.state == XMGRemoteAudioPlayerStatePause) {
            [self resume];
            return;
        }
        
    }
    
    
    self.url = url;
    // 播放器对象
    // 内部封装了三个步骤
    //    AVPlayer *player = [AVPlayer playerWithURL:url];
    // 1. 资源的请求
    NSURL *resultURL = url;
    if (isCache) {
        resultURL = [url xmgURL];
    }
    AVURLAsset *asset = [AVURLAsset assetWithURL:resultURL];
    if (self.player.currentItem) {
        [self clearObserver];
    }
    self.loader = [XMGResourceLoader new];
    // 必须是自定义协议
    [asset.resourceLoader setDelegate:self.loader queue:dispatch_get_main_queue()];
    // 2. 资源的组织
     AVPlayerItem *item = [AVPlayerItem playerItemWithAsset:asset];
    
    [item addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    [item addObserver:self forKeyPath:@"playbackLikelyToKeepUp" options:NSKeyValueObservingOptionNew context:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playEnd) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playInterupt) name:AVPlayerItemPlaybackStalledNotification object:nil];
    // 3. 资源的播放
    self.player = [AVPlayer playerWithPlayerItem:item];

    // 一定要注意, 一般不是直接去调用
//    [player play];
    
   
}


- (void)pause {
    [self.player pause];
    if (self.player) {
        _isUserPause = YES;
        self.state = XMGRemoteAudioPlayerStatePause;
    }
    
}

- (void)resume {
    [self.player play];
    if (self.player.rate != 0.0) {
        _isUserPause = NO;
        self.state = XMGRemoteAudioPlayerStatePlaying;
    }
    
}

- (void)stop {
    [self.player pause];
    [self clearObserver];
    self.player = nil;
    _isUserPause = YES;
    self.state = XMGRemoteAudioPlayerStateStopped;
}

// 15
- (void)seekWithTimeInterval:(NSTimeInterval)timeInterval {
    
    
    
    
//    CMTime 影片时间
    // 影片时间-> 秒
    //CMTimeGetSeconds(<#CMTime time#>);
    // 秒 -> 影片时间
    //CMTimeMake(秒, NSEC_PER_SEC)
    
    // 1. 获取当前播放时间 + 15
    NSTimeInterval sec = CMTimeGetSeconds(self.player.currentItem.currentTime) + timeInterval;
    
    
    [self.player seekToTime:CMTimeMakeWithSeconds(sec, NSEC_PER_SEC) completionHandler:^(BOOL finished) {
        if (finished) {
            NSLog(@"确定加载这个时间段的资源");
        }else {
             NSLog(@"取消加载这个时间段的资源");
        }
    }];
    
}

- (void)seekToProgress:(float)progress {
    
    NSTimeInterval sec = CMTimeGetSeconds(self.player.currentItem.duration) * progress;
    
    [self.player seekToTime:CMTimeMakeWithSeconds(sec, NSEC_PER_SEC) completionHandler:^(BOOL finished) {
        if (finished) {
            NSLog(@"确定加载这个时间段的资源");
        }else {
            NSLog(@"取消加载这个时间段的资源");
        }
    }];

    
}

- (void)setRate:(float)rate {
    self.player.rate = rate;
}

- (void)setMuted:(BOOL)muted {
    self.player.muted = muted;
}

- (void)setVolume:(float)volume {
    if (volume > 0.0) {
        self.muted = NO;
    }
    [self.player setVolume:volume];
}


- (float)rate {
    return self.player.rate;
}

- (BOOL)muted {
    return self.player.muted;
}

- (float)volume {
    return self.player.volume;
}

- (NSTimeInterval)duration {
    
    NSTimeInterval totalTime = CMTimeGetSeconds(self.player.currentItem.duration);
    if (isnan(totalTime)) {
        return 0.0;
    }
    return totalTime;
    
}

- (NSTimeInterval)currentTime {
    
    NSTimeInterval currTime = CMTimeGetSeconds(self.player.currentItem.currentTime);
    if (isnan(currTime)) {
        return 0.0;
    }
    return currTime;
    
}


- (float)progress {
    if (self.duration == 0.0) {
        return 0;
    }
    return self.currentTime / self.duration;
}

- (float)loadProgress {
    
    if (self.duration == 0.0) {
        return 0;
    }
    
    CMTimeRange range = [self.player.currentItem.loadedTimeRanges.lastObject CMTimeRangeValue];
    CMTime loadTime = CMTimeAdd(range.start, range.duration);
    NSTimeInterval loadTiemSec = CMTimeGetSeconds(loadTime);
    
    return  (loadTiemSec / self.duration);
}


- (void)playInterupt {
    NSLog(@"播放被打断");
    self.state = XMGRemoteAudioPlayerStatePause;
}

- (void)playEnd {
    NSLog(@"播放完成");
    self.state = XMGRemoteAudioPlayerStateStopped;
}


//@property (nonatomic, assign) float rate;
//@property (nonatomic, assign) BOOL muted;
//@property (nonatomic, assign) float volume;



- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    if([keyPath isEqualToString:@"status"]) {
       AVPlayerItemStatus status =  [change[NSKeyValueChangeNewKey] integerValue];
        
        switch (status) {
            case AVPlayerItemStatusUnknown:
            {
                NSLog(@"资源无效");
                self.state = XMGRemoteAudioPlayerStateFailed;
                break;
            }
            case AVPlayerItemStatusReadyToPlay:
            {
                NSLog(@"资源准备好了, 已经可以播放");
                [self resume];
                break;
            }
            case AVPlayerItemStatusFailed:
            {
                NSLog(@"资源加载失败");
                self.state = XMGRemoteAudioPlayerStateFailed;
                break;
            }
                
            default:
                break;
        }
        
    }
    
    if ([keyPath isEqualToString:@"playbackLikelyToKeepUp"]) {
        BOOL playbackLikelyToKeepUp = [change[NSKeyValueChangeNewKey] boolValue];
        if (playbackLikelyToKeepUp) {
            NSLog(@"资源加载的可以播放了");
            
            // 具体要不要自动播放, 不能确定;
            // 用户手动暂停优先级, 最高 > 自动播放
            if (!_isUserPause) {
                [self resume];
            }
            
        }else {
            
            NSLog(@"资源正在加载");
            self.state = XMGRemoteAudioPlayerStateLoading;
        }
    }
    
    
}


- (void)clearObserver {
     [self.player.currentItem removeObserver:self forKeyPath:@"status"];
     [self.player.currentItem removeObserver:self forKeyPath:@"playbackLikelyToKeepUp"];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)setUrl:(NSURL *)url {
    _url = url;
}

- (void)setState:(XMGRemoteAudioPlayerState)state {
    _state = state;
}

@end
