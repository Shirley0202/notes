//
//  XMGRemotePlayer.h
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 播放器的状态
 * 因为UI界面需要加载状态显示, 所以需要提供加载状态
 - XMGRemoteAudioPlayerStateUnknown: 未知(比如都没有开始播放音乐)
 - XMGRemoteAudioPlayerStateLoading: 正在加载()
 - XMGRemoteAudioPlayerStatePlaying: 正在播放
 - XMGRemoteAudioPlayerStateStopped: 停止
 - XMGRemoteAudioPlayerStatePause:   暂停
 - XMGRemoteAudioPlayerStateFailed:  失败(比如没有网络缓存失败, 地址找不到)
 */
typedef NS_ENUM(NSInteger, XMGRemoteAudioPlayerState) {
    XMGRemoteAudioPlayerStateUnknown = 0,
    XMGRemoteAudioPlayerStateLoading   = 1,
    XMGRemoteAudioPlayerStatePlaying   = 2,
    XMGRemoteAudioPlayerStateStopped   = 3,
    XMGRemoteAudioPlayerStatePause     = 4,
    XMGRemoteAudioPlayerStateFailed    = 5
};


@interface XMGRemotePlayer : NSObject

+ (instancetype)shareInstance;

- (void)playWithUrl:(NSURL *)url isCache:(BOOL)isCache;

- (void)pause;

- (void)resume;

- (void)stop;

- (void)seekWithTimeInterval:(NSTimeInterval)timeInterval;

- (void)seekToProgress:(float)progress;

@property (nonatomic, weak, readonly) NSURL *url;

@property (nonatomic, assign) float rate;
@property (nonatomic, assign) BOOL muted;
@property (nonatomic, assign) float volume;

@property (nonatomic, assign, readonly) NSTimeInterval duration;
@property (nonatomic, assign, readonly) NSTimeInterval currentTime;

@property (nonatomic, assign, readonly) float progress;

@property (nonatomic, assign, readonly) float loadProgress;

@property (nonatomic, assign, readonly) XMGRemoteAudioPlayerState state;

@end
