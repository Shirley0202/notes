//
//  XMGRemotePlayerDownLoader.h
//  播放器
//
//  Created by seemygo on 17/3/5.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol XMGRemotePlayerDownLoaderDelegate <NSObject>

- (void)reciveNewData;

@end



@interface XMGRemotePlayerDownLoader : NSObject

@property (nonatomic, weak) id<XMGRemotePlayerDownLoaderDelegate> delegate;

@property (nonatomic, assign) long long loadedSize;
@property (nonatomic, assign) long long offset;
@property (nonatomic, assign) long long totalSize;
@property (nonatomic, copy) NSString *contentType;
@property (nonatomic, strong) NSURL *url;


- (void)downLoadWithURL:(NSURL *)url offset:(long long)offset;


@end
