//
//  XMGResourceLoader.m
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGResourceLoader.h"
#import "XMGRemotePlayerAudioFile.h"
#import "XMGRemotePlayerDownLoader.h"
#import "NSURL+Custom.h"

@interface XMGResourceLoader()<XMGRemotePlayerDownLoaderDelegate>

@property (nonatomic, strong) XMGRemotePlayerDownLoader *downLoader;

@property (nonatomic, strong) NSMutableArray<AVAssetResourceLoadingRequest *> *loadRequests;

@end


@implementation XMGResourceLoader

- (XMGRemotePlayerDownLoader *)downLoader {
    if (!_downLoader) {
        _downLoader = [[XMGRemotePlayerDownLoader alloc] init];
        _downLoader.delegate = self;
    }
    return _downLoader;
}


- (NSMutableArray *)loadRequests {
    if (!_loadRequests) {
        _loadRequests = [NSMutableArray array];
    }
    return _loadRequests;
}


/**
 负责处理所有的资源加载请求
 */
- (void)handleAllLoadingRequests {
    
    NSMutableArray *deleteRequests = [NSMutableArray array];
    for (AVAssetResourceLoadingRequest *loadingRequest in self.loadRequests) {
        
        if ([loadingRequest isFinished] || [loadingRequest isCancelled]) {
            [deleteRequests addObject:loadingRequest];
            continue;
        }
        
        // 1. loadingRequest, 填充内容信息
        loadingRequest.contentInformationRequest.contentType = self.downLoader.contentType;
        loadingRequest.contentInformationRequest.contentLength = self.downLoader.totalSize;
        loadingRequest.contentInformationRequest.byteRangeAccessSupported = YES;
        
        // 2. 响应内容数据
        NSData *data = [NSData dataWithContentsOfFile:[XMGRemotePlayerAudioFile tmpAudioFilePath:self.downLoader.url] options:NSDataReadingMappedIfSafe error:nil];
        if (data.length == 0) {
            data = [NSData dataWithContentsOfFile:[XMGRemotePlayerAudioFile cacheAudioFilePath:self.downLoader.url] options:NSDataReadingMappedIfSafe error:nil];
        }
        if (data.length == 0) {
            break;
        }
        
        long long requestOffset = loadingRequest.dataRequest.requestedOffset;
        if (loadingRequest.dataRequest.currentOffset != 0) {
            requestOffset = loadingRequest.dataRequest.currentOffset;
        }
        long long requestLength = loadingRequest.dataRequest.requestedLength;
        
        
        long long responseOffset = requestOffset - self.downLoader.offset;
        long long responseLength = MIN(self.downLoader.offset + self.downLoader.loadedSize - requestOffset, requestLength);
        
        NSData *subData = [data subdataWithRange:NSMakeRange(responseOffset, responseLength)];
        
        [loadingRequest.dataRequest respondWithData:subData];
        
        // 3. 如果响应完毕, 直接完成
        if (responseLength == requestLength) {
            [loadingRequest finishLoading];
            [deleteRequests addObject:loadingRequest];
        }
 
    }
    
    [self.loadRequests removeObjectsInArray:deleteRequests];
    

    
}


- (BOOL)resourceLoader:(AVAssetResourceLoader *)resourceLoader shouldWaitForLoadingOfRequestedResource:(AVAssetResourceLoadingRequest *)loadingRequest  {
    
    NSLog(@"%@", loadingRequest);
    [self.loadRequests addObject:loadingRequest];
    
    AVAssetResourceLoadingRequest *lr = self.loadRequests.firstObject;
    
    NSURL *url = lr.request.URL;
    // 1. 根据请求的资源地址, 判定, 本地有没有缓存(路径), 如果已经下载完毕, 直接加载本地的音频资源 , return
    // 1.1 拿到拼接路径
    // 1.2 判断路径是否存在
    // 1.3  url, -> 判定url地址对应的下载完成路径是否存在
    if ([XMGRemotePlayerAudioFile fileExistsWithAudioURL:url]) {
        
        [self handleLoadingRequest:lr];
        return YES;
    }
    
    
    // 2. 应该判断, 当前下载器是否有开始下载过, 如果没有, 下载(url, requestOffset) retrun
    long long requestOffset = lr.dataRequest.requestedOffset;
//    if (loadingRequest.dataRequest.currentOffset != 0) {
//        requestOffset = loadingRequest.dataRequest.currentOffset;
//    }
//    loadingRequest.dataRequest.requestedLength
    if (self.downLoader.loadedSize == 0) {
        [self.downLoader downLoadWithURL:[url httpURL] offset:requestOffset];
        return YES;
    }
    
    
    // 3. 当前是有正在下载, 但是我们依然需要判断, 是否需要重新下载
    // 3.1 当前的请求节点  > 下载节点+下载长度+容错区间(666)
    // 3.2 当前的请求节点 < 下载节点
    // return
    if (requestOffset > self.downLoader.offset + self.downLoader.loadedSize + 666 || requestOffset < self.downLoader.offset) {
        [self.downLoader downLoadWithURL:[url httpURL] offset:requestOffset];
        return YES;
    }
 
    
    // 4. 当前是有正在下载, 不需要重新下载(请求的字节区间, 数据, 就在我的下载当中)
    // 直接处理请求(不一定一次能够完全处理完毕), 另外一个地方处理请求(下载当中)
    [self handleAllLoadingRequests];


    return YES;

}

- (void)resourceLoader:(AVAssetResourceLoader *)resourceLoader didCancelLoadingRequest:(AVAssetResourceLoadingRequest *)loadingRequest {
    
//    [self.loadRequests removeObject:loadingRequest];
    [loadingRequest finishLoading];
}


- (void)handleLoadingRequest:(AVAssetResourceLoadingRequest *)loadingRequest {
    NSURL *url = loadingRequest.request.URL;
    // 1. 搞数据
    NSData *data = [NSData dataWithContentsOfFile:[XMGRemotePlayerAudioFile cacheAudioFilePath:url] options:NSDataReadingMappedIfSafe error:nil];
    
    // 2. 把数据传递给外界(资源的组织者-> 播放器)
    loadingRequest.contentInformationRequest.contentType = [XMGRemotePlayerAudioFile contentTypeWithURL:url];
    loadingRequest.contentInformationRequest.contentLength = [XMGRemotePlayerAudioFile fileExistsWithAudioURL:url];
    loadingRequest.contentInformationRequest.byteRangeAccessSupported = YES;
    
    long long requestOffset = loadingRequest.dataRequest.requestedOffset;
    long long requestLength = loadingRequest.dataRequest.requestedLength;
    
    NSData *subData = [data subdataWithRange:NSMakeRange(requestOffset, requestLength)];
    
    [loadingRequest.dataRequest respondWithData:subData];
    [loadingRequest finishLoading];
    
    
}

#pragma mark - XMGRemotePlayerDownLoaderDelegate

- (void)reciveNewData {
    [self handleAllLoadingRequests];
}


@end
