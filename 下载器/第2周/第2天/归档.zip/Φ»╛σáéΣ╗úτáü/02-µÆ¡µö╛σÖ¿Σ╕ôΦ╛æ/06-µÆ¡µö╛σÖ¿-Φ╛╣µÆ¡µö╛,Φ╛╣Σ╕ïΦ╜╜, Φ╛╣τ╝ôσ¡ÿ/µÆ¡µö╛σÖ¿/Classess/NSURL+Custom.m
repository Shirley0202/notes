//
//  NSURL+Custom.m
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "NSURL+Custom.h"

@implementation NSURL (Custom)

- (NSURL *)xmgURL {
//http://www
//xmg://wwww
    NSURLComponents *compents = [NSURLComponents componentsWithString:self.absoluteString];
    compents.scheme = @"xmg";
    return compents.URL;
}

- (NSURL *)httpURL {
    NSURLComponents *compents = [NSURLComponents componentsWithString:self.absoluteString];
    compents.scheme = @"http";
    return compents.URL;
}

@end
