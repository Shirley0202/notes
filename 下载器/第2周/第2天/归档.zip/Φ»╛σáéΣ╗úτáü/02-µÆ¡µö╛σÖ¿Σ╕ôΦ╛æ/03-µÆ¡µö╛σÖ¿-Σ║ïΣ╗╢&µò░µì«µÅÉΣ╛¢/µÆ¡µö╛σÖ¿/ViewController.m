//
//  ViewController.m
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "ViewController.h"
#import "XMGRemotePlayer.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *costTimeLabel;

@property (weak, nonatomic) IBOutlet UILabel *totalTimeLabel;
@property (weak, nonatomic) IBOutlet UISlider *loadSlider;

@property (weak, nonatomic) IBOutlet UISlider *playSlider;
@property (weak, nonatomic) IBOutlet UISlider *volumeSlider;

@property (nonatomic, weak) NSTimer *timer;

@end

@implementation ViewController

- (NSTimer *)timer {
    if (!_timer) {
        NSTimer *timer = [NSTimer timerWithTimeInterval:1 target:self selector:@selector(update) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
        _timer = timer;
    }
    return _timer;
}

- (IBAction)play:(id)sender {
    NSURL *url = [NSURL URLWithString:@"http://audio.xmcdn.com/group22/M0B/60/85/wKgJM1g1g0ShoPalAJiI5nj3-yY200.m4a"];
    [[XMGRemotePlayer shareInstance] playWithUrl:url];
}

- (IBAction)pause:(id)sender {
    [[XMGRemotePlayer shareInstance] pause];
}
- (IBAction)resume:(id)sender {
    [[XMGRemotePlayer shareInstance] resume];
}

- (IBAction)stop:(id)sender {
    [[XMGRemotePlayer shareInstance] stop];
}


- (IBAction)kuaijin15:(id)sender {
    [[XMGRemotePlayer shareInstance] seekWithTimeInterval:15];
}

- (IBAction)progress:(UISlider *)sender {
    [[XMGRemotePlayer shareInstance] seekToProgress:sender.value];
}
- (IBAction)doubleRate:(id)sender {
    [XMGRemotePlayer shareInstance].rate = 2.0;
}
- (IBAction)volume:(UISlider *)sender {
    [XMGRemotePlayer shareInstance].volume = sender.value;
}
- (IBAction)mute:(id)sender {
    [XMGRemotePlayer shareInstance].muted = ![XMGRemotePlayer shareInstance].muted;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self timer];
}

- (void)update {
    
    self.costTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", (int)[XMGRemotePlayer shareInstance].currentTime / 60, (int)[XMGRemotePlayer shareInstance].currentTime % 60];
    
    self.totalTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", (int)[XMGRemotePlayer shareInstance].duration / 60, (int)[XMGRemotePlayer shareInstance].duration % 60];
    
    self.loadSlider.value = [XMGRemotePlayer shareInstance].loadProgress;
    
    self.playSlider.value = [XMGRemotePlayer shareInstance].progress;
    self.volumeSlider.value = [XMGRemotePlayer shareInstance].volume;
    
}


@end
