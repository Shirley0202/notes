//
//  XMGRemotePlayer.h
//  播放器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMGRemotePlayer : NSObject

+ (instancetype)shareInstance;

- (void)playWithUrl:(NSURL *)url;

- (void)pause;

- (void)resume;

- (void)stop;

- (void)seekWithTimeInterval:(NSTimeInterval)timeInterval;

- (void)seekToProgress:(float)progress;

@property (nonatomic, weak, readonly) NSURL *url;

@property (nonatomic, assign) float rate;
@property (nonatomic, assign) BOOL muted;
@property (nonatomic, assign) float volume;

@property (nonatomic, assign, readonly) NSTimeInterval duration;
@property (nonatomic, assign, readonly) NSTimeInterval currentTime;

@property (nonatomic, assign, readonly) float progress;

@property (nonatomic, assign, readonly) float loadProgress;


@end
