//
//  XMGDownLoader.m
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGDownLoader.h"
#import "XMGFileTool.h"

#define kCache  NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject

@interface XMGDownLoader ()<NSURLSessionDataDelegate>
{
    long long _fileTmpSize;
    long long _totalSize;
}
@property (nonatomic, strong) NSURLSession *session;

@property (nonatomic, copy) NSString *downLoadedFilePath;
@property (nonatomic, copy) NSString *downLoadingFilePath;

@property (nonatomic, strong) NSOutputStream *outputStream;

@end


@implementation XMGDownLoader

- (void)downLoadWithURL:(NSURL *)url {

    // 思路理清楚
    // 伪代码
    // oc swift c
    
    // 0. 存储机制
    // 下载完成 cache/downLoader/downloaded/url.lastCompent
    // 下载中 cache/downLoader/downloading/url.lastCompent
    self.downLoadedFilePath = [self.downLoadedPath stringByAppendingPathComponent:url.lastPathComponent];
    self.downLoadingFilePath = [self.downLoadingPath stringByAppendingPathComponent:url.lastPathComponent];
    
    
    
    // 1. 判断当前url对应的资源是否已经下载完毕, 如果已经下载完毕, 直接返回
    // 1.1 通过一些辅助信息, 去记录那些文件已经下载完毕(额外维护信息文件)
    // 1.2 下载完成的路径 和  临时下载的文件路径分离
    // http://www.520it.com/xx.zip
    //     cache/downLoader/downloaded/url.lastCompent   cache/downLoader/downloading
    // sdwebimage 文件名称 url md5 image a.png
    if ([XMGFileTool fileExistsAtPath:self.downLoadedFilePath]) {
        NSLog(@"当前资源已经下载完毕");
        return;
    }
    
    // 2. 检测, 本地有没有下载过临时缓存,
    // 2.1 没有本地缓存, 从0字节开始下载(断点下载 HTTP, RANGE "bytes=开始-"), return
    if (![XMGFileTool fileExistsAtPath:self.downLoadingFilePath]) {
        [self downLoadWithURL:url offset:_fileTmpSize];
        return;
    }

    // 2.2 获取本地缓存的大小ls : 文件真正正确的总大小rs
    _fileTmpSize = [XMGFileTool fileSizeAtPath:self.downLoadingFilePath];
    [self downLoadWithURL:url offset:_fileTmpSize];
    
}



/**
 根据url地址, 偏移量进行下载

 @param url url资源
 @param offset 偏移量
 */
- (void)downLoadWithURL:(NSURL *)url offset:(long long)offset {
    
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:0];
    [request setValue:[NSString stringWithFormat:@"bytes=%lld-", offset] forHTTPHeaderField:@"Range"];
    NSURLSessionDataTask *task = [self.session dataTaskWithRequest:request];
    [task resume];
    
}


#pragma mark - NSURLSessionDataDelegate


/**
 第一次接受到下载信息 响应头信息的时候调用

 @param session 会话
 @param dataTask 任务
 @param response 相应头
 @param completionHandler 系统回调, 可以通过这个回调, 传递不同的参数, 来决定是否需要继续接受后续数据
 */
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSHTTPURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler
{
    NSLog(@"%@", response);
    // 2.2.1  ls < rs => 直接接着下载 ls
    // 2.2.2 ls == rs => 移动到下载完成文件夹()
    // 2.2.3 ls > rs => 删除本地临时缓存, 从0开始下载
    // 21574062
    // 21574062
    // 21573062
    
    // 本地大小
    
    // 总大小
    // "bytes 1000-21574061/21574062";
    NSString *rangeStr = response.allHeaderFields[@"Content-Range"];
    _totalSize = [[rangeStr componentsSeparatedByString:@"/"].lastObject longLongValue];
    
    if (_fileTmpSize == _totalSize) {
        // 大小相等, 不一定, 代表文件完整, 正确 .zip
        // 验证文件的完整性, -> 移动操作
        NSLog(@"下载完成, 执行移动操作");
        [XMGFileTool moveFileFromPath:self.downLoadingFilePath toPath:self.downLoadedFilePath];
        completionHandler(NSURLSessionResponseCancel);
        return;
    }
    
    if (_fileTmpSize > _totalSize) {
        NSLog(@"清除本地缓存, 然后, 从0开始下载, 并且, 取消本次请求");
        // 清除本地缓存
        [XMGFileTool removeFileAtPath:self.downLoadingFilePath];
        // 取消本次请求
        completionHandler(NSURLSessionResponseCancel);
        // 从0开始下载
        [self downLoadWithURL:response.URL];
        
        return;
    }
    
    
    // 创建文件输出流
    self.outputStream = [NSOutputStream outputStreamToFileAtPath:self.downLoadingFilePath append:YES];
    [self.outputStream open];
    
    NSLog(@"继续接受数据");
    completionHandler(NSURLSessionResponseAllow);
    
}


/**
 如果是可以接受后续数据, 那么在接受过程中, 就会调用这个方法

 @param session 会话
 @param dataTask 任务
 @param data 接受到的数据, 一段
 */
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    NSLog(@"在接受数据");
    _fileTmpSize += data.length;
    [self.outputStream write:data.bytes maxLength:data.length];

}



/**
 请求完毕, != 下载完毕

 @param session 会话
 @param task 任务
 @param error 错误
 */
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error
{
    
    
    if (!error) {
        // 开始字节 - 最后
        NSLog(@"本次请求完成");
        // w为了严谨, 再次验证
        // 文件完整性验证
        if (_fileTmpSize == _totalSize) {
            [XMGFileTool moveFileFromPath:self.downLoadingFilePath toPath:self.downLoadedFilePath];
        }
    }else {
        NSLog(@"有错误--%@", error);
    }
    
    
    
}



#pragma mark - seter geter

- (NSURLSession *)session {
    if (!_session) {
        _session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:self delegateQueue:[NSOperationQueue new]];
    }
    return _session;
}
- (NSString *)downLoadingPath {
    
    NSString *path = [kCache stringByAppendingPathComponent:@"downLoader/downloading"];
    
    BOOL result = [XMGFileTool createDirectoryIfNotExists:path];
    if (result) {
        return path;
    }
    return @"";
    
}

- (NSString *)downLoadedPath {
    NSString *path = [kCache stringByAppendingPathComponent:@"downLoader/downloaded"];
    
    BOOL result = [XMGFileTool createDirectoryIfNotExists:path];
    if (result) {
        return path;
    }
    return @"";
}



@end
