//
//  XMGDownLoaderManager.m
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGDownLoaderManager.h"
#import "NSString+MD5.h"

@interface XMGDownLoaderManager ()<NSCopying, NSMutableCopying>

// key : url MD5  value: 下载器
@property (nonatomic, strong) NSMutableDictionary *downLoadInfo;

@end


@implementation XMGDownLoaderManager

static XMGDownLoaderManager *_shareInstance;

+ (instancetype)shareInstance {
    if (!_shareInstance) {
        _shareInstance = [[self alloc] init];
    }
    return _shareInstance;
}


+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    if (!_shareInstance) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _shareInstance = [super allocWithZone:zone];
        });
    }
    return _shareInstance;
}

- (id)copyWithZone:(NSZone *)zone {
    return _shareInstance;
}


- (id)mutableCopyWithZone:(NSZone *)zone {
    return _shareInstance;
}





- (NSMutableDictionary *)downLoadInfo {
    if (!_downLoadInfo) {
        _downLoadInfo = [NSMutableDictionary dictionary];
    }
    return _downLoadInfo;

}


- (void)downLoadWithURL:(NSURL *)url messageBlock:(DownLoadMessage)messageBlock progress:(DownLoadProgressChange)progressBlock success:(DownLoadSuccess)successBlock failed:(DownLoadFailed)failedBlock {
    
    // 先获取下载器,
    NSString *urlStr = [url.absoluteString md5Str];
    XMGDownLoader *downLoader = self.downLoadInfo[urlStr];
    
    // 创建一个下载器
    if (downLoader == nil) {
        downLoader = [[XMGDownLoader alloc] init];
        self.downLoadInfo[urlStr] = downLoader;
    }
    // 调用下载器 down
    __weak typeof(self) weakSelf = self;
    [downLoader downLoadWithURL:url messageBlock:messageBlock progress:progressBlock success:^(NSString *downLoadedPath) {
        [weakSelf.downLoadInfo removeObjectForKey:urlStr];
        
        if (successBlock) {
            successBlock(downLoadedPath);
        }
    } failed:failedBlock];
    
}

- (void)pauseWithURL:(NSURL *)url {
    
    NSString *urlStr = [url.absoluteString md5Str];
    XMGDownLoader *downLoader = self.downLoadInfo[urlStr];
    [downLoader pause];

}

- (void)pauseAll {
    [self.downLoadInfo.allValues performSelector:@selector(pause) withObject:nil];
}


@end
