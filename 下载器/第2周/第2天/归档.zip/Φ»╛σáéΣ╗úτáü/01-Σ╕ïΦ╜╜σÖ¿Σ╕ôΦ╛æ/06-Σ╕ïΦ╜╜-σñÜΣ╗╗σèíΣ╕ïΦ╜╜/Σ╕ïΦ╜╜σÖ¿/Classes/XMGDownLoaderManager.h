//
//  XMGDownLoaderManager.h
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMGDownLoader.h"

@interface XMGDownLoaderManager : NSObject

// 单例, 绝对单例
// 不绝对单例: 可以通过某个方法, 获取同一个对象, 也可以通过其他方法, 获取新的对象
+ (instancetype)shareInstance;

- (void)downLoadWithURL:(NSURL *)url messageBlock:(DownLoadMessage)messageBlock progress:(DownLoadProgressChange)progressBlock success:(DownLoadSuccess)successBlock failed:(DownLoadFailed)failedBlock;

- (void)pauseWithURL:(NSURL *)url;

- (void)pauseAll;


@end
