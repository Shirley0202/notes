//
//  ViewController.m
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "ViewController.h"
#import "XMGDownLoader.h"

@interface ViewController ()

@property (nonatomic, strong) XMGDownLoader *downLoader;

@end

@implementation ViewController

- (XMGDownLoader *)downLoader {
    if (!_downLoader) {
        _downLoader = [XMGDownLoader new];
    }
    return _downLoader;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURL *url = [NSURL URLWithString:@"http://free2.macx.cn:8281/tools/photo/Sip44.dmg"];
    [self.downLoader downLoadWithURL:url];
    
}


@end
