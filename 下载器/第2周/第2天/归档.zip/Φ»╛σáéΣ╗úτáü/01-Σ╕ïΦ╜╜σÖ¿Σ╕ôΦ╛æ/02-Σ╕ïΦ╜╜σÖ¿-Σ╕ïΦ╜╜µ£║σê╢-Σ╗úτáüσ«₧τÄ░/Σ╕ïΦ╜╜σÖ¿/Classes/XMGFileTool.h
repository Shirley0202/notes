//
//  XMGFileTool.h
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMGFileTool : NSObject

+ (BOOL)createDirectoryIfNotExists:(NSString *)path;

+ (BOOL)fileExistsAtPath:(NSString *)path;

+ (long long)fileSizeAtPath:(NSString *)path;

+ (void)removeFileAtPath:(NSString *)path;

@end
