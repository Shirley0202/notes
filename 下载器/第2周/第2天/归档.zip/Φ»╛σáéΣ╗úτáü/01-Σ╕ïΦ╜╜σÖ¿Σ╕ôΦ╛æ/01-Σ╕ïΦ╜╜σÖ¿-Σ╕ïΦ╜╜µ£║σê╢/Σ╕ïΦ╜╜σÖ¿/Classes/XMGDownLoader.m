//
//  XMGDownLoader.m
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGDownLoader.h"

@implementation XMGDownLoader

- (void)downLoadWithURL:(NSURL *)url {
    
    
    // 思路理清楚
    // 伪代码
    // oc swift c
    
    // 0. 存储机制
    // 下载完成 cache/downLoader/downloaded/url.lastCompent
    // 下载中 cache/downLoader/downloading/url.lastCompent
    
    
    // 1. 判断当前url对应的资源是否已经下载完毕, 如果已经下载完毕, 直接返回
    // 1.1 通过一些辅助信息, 去记录那些文件已经下载完毕(额外维护信息文件)
    // 1.2 下载完成的路径 和  临时下载的文件路径分离
    // http://www.520it.com/xx.zip
    //     cache/downLoader/downloaded/url.lastCompent   cache/downLoader/downloading
    // sdwebimage 文件名称 url md5 image a.png

    
    // 2. 检测, 本地有没有下载过临时缓存,
    // 2.1 没有本地缓存, 从0字节开始下载(断点下载 HTTP, RANGE "bytes=开始-"), return
    
    // 2.2 获取本地缓存的大小ls : 文件真正正确的总大小rs
    // 2.2.1  ls < rs => 直接接着下载 ls
    // 2.2.2 ls == rs => 移动到下载完成文件夹()
    // 2.2.3 ls > rs => 删除本地临时缓存, 从0开始下载
    
    
    
    
    
    
    
    
    
}


@end
