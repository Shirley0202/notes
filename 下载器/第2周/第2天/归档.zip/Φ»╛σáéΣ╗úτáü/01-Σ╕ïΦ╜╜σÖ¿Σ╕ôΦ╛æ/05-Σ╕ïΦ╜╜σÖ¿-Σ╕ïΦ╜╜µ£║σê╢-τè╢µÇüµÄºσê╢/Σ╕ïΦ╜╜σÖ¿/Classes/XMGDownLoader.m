//
//  XMGDownLoader.m
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "XMGDownLoader.h"
#import "XMGFileTool.h"

#define kCache  NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject

@interface XMGDownLoader ()<NSURLSessionDataDelegate>
{
    long long _fileTmpSize;
    long long _totalSize;
}
@property (nonatomic, strong) NSURLSession *session;

@property (nonatomic, copy) NSString *downLoadedFilePath;
@property (nonatomic, copy) NSString *downLoadingFilePath;

@property (nonatomic, strong) NSOutputStream *outputStream;

@property (nonatomic, weak) NSURLSessionDataTask *task;

@end


@implementation XMGDownLoader

#pragma mark - 接口


- (void)downLoadWithURL:(NSURL *)url messageBlock:(DownLoadMessage)messageBlock progress:(DownLoadProgressChange)progressBlock success:(DownLoadSuccess)successBlock failed:(DownLoadFailed)failedBlock {
    
    self.messageBlock = messageBlock;
    self.progressBlock = progressBlock;
    self.successBlock = successBlock;
    self.failedBlock = failedBlock;
    
    [self downLoadWithURL:url];
    
    
}

// 下载动作内部, 涵盖了继续这个动作
- (void)downLoadWithURL:(NSURL *)url {

    // 容错处理, 判断任务是否已经存在
    if ([url isEqual:self.task.originalRequest.URL]) {
        
        // 任务存在, 还需要判断状态
        if (self.state == XMGDownLoaderStatePause) {
            [self resume];
            return;
        }
        if (self.state == XMGDownLoaderStateDowning) {
            return;
        }
        if (self.state == XMGDownLoaderStateSuccess) {
            NSLog(@"告诉外界");
            return;
        }
//        if (self.state == XMGDownLoaderStateFailed) {
//            
//        }
    }
    
    // 任务不存在
    // 任务存在, 但是url地址不一致
    
    // 思路理清楚
    // 伪代码
    // oc swift c
    
    // 0. 存储机制
    // 下载完成 cache/downLoader/downloaded/url.lastCompent
    // 下载中 cache/downLoader/downloading/url.lastCompent
    self.downLoadedFilePath = [self.downLoadedPath stringByAppendingPathComponent:url.lastPathComponent];
    self.downLoadingFilePath = [self.downLoadingPath stringByAppendingPathComponent:url.lastPathComponent];
    
    
    
    // 1. 判断当前url对应的资源是否已经下载完毕, 如果已经下载完毕, 直接返回
    // 1.1 通过一些辅助信息, 去记录那些文件已经下载完毕(额外维护信息文件)
    // 1.2 下载完成的路径 和  临时下载的文件路径分离
    // http://www.520it.com/xx.zip
    //     cache/downLoader/downloaded/url.lastCompent   cache/downLoader/downloading
    // sdwebimage 文件名称 url md5 image a.png
    if ([XMGFileTool fileExistsAtPath:self.downLoadedFilePath]) {
        if (self.successBlock) {
            self.successBlock(self.downLoadedFilePath);
        }
        return;
    }
    
    // 2. 检测, 本地有没有下载过临时缓存,
    // 2.1 没有本地缓存, 从0字节开始下载(断点下载 HTTP, RANGE "bytes=开始-"), return
    if (![XMGFileTool fileExistsAtPath:self.downLoadingFilePath]) {
        [self downLoadWithURL:url offset:_fileTmpSize];
        return;
    }

//    [self.session invalidateAndCancel];
//    self.session = nil;
    
    [self cancel];
    // 2.2 获取本地缓存的大小ls : 文件真正正确的总大小rs
    _fileTmpSize = [XMGFileTool fileSizeAtPath:self.downLoadingFilePath];
    [self downLoadWithURL:url offset:_fileTmpSize];
    
}



- (void)cancel {
//    [self.task suspend];
//    self.state = XMGDownLoaderStateFailed;
    // 取消所有的请求, 并且会销毁资源
    [self.session invalidateAndCancel];
    self.session = nil;
}

// 暂停了几次, 就得继续几次, 才能继续
- (void)resume{
    if ((self.task && self.state == XMGDownLoaderStatePause) || self.state == XMGDownLoaderStateFailed) {
        [self.task resume];
        self.state = XMGDownLoaderStateDowning;
    }
    
}

// 继续了几次, 暂停几次, 才能暂停
// 通过状态
- (void)pause {
    if (self.state == XMGDownLoaderStateDowning) {
        [self.task suspend];
        self.state = XMGDownLoaderStatePause;
    }
}

- (void)cancelAndClean {
    [self cancel];
    [XMGFileTool removeFileAtPath:self.downLoadingFilePath];
}

#pragma mark - 私有方法


/**
 根据url地址, 偏移量进行下载

 @param url url资源
 @param offset 偏移量
 */
- (void)downLoadWithURL:(NSURL *)url offset:(long long)offset {
    
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:0];
    [request setValue:[NSString stringWithFormat:@"bytes=%lld-", offset] forHTTPHeaderField:@"Range"];
    self.task = [self.session dataTaskWithRequest:request];
    [self resume];
    
    
}


#pragma mark - NSURLSessionDataDelegate


/**
 第一次接受到下载信息 响应头信息的时候调用

 @param session 会话
 @param dataTask 任务
 @param response 相应头
 @param completionHandler 系统回调, 可以通过这个回调, 传递不同的参数, 来决定是否需要继续接受后续数据
 */
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSHTTPURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler
{
    // 2.2.1  ls < rs => 直接接着下载 ls
    // 2.2.2 ls == rs => 移动到下载完成文件夹()
    // 2.2.3 ls > rs => 删除本地临时缓存, 从0开始下载
    // 21574062
    // 21574062
    // 21573062
    
    // 本地大小
    
    // 总大小
    // "bytes 1000-21574061/21574062";
    NSString *rangeStr = response.allHeaderFields[@"Content-Range"];
    _totalSize = [[rangeStr componentsSeparatedByString:@"/"].lastObject longLongValue];
    
    if (_fileTmpSize == _totalSize) {
        // 大小相等, 不一定, 代表文件完整, 正确 .zip
        // 验证文件的完整性, -> 移动操作

        [XMGFileTool moveFileFromPath:self.downLoadingFilePath toPath:self.downLoadedFilePath];
        completionHandler(NSURLSessionResponseCancel);
        if (self.successBlock) {
            self.successBlock(self.downLoadedFilePath);
        }
        return;
    }
    
    if (_fileTmpSize > _totalSize) {
        
        // 清除本地缓存
        [XMGFileTool removeFileAtPath:self.downLoadingFilePath];
        // 取消本次请求
        completionHandler(NSURLSessionResponseCancel);
        // 从0开始下载
        [self downLoadWithURL:response.URL];
        
        return;
    }
    
    if (self.messageBlock) {
        self.messageBlock(_totalSize, self.downLoadedFilePath);
    }
    
    // 创建文件输出流
    self.outputStream = [NSOutputStream outputStreamToFileAtPath:self.downLoadingFilePath append:YES];
    [self.outputStream open];
    
    
    completionHandler(NSURLSessionResponseAllow);
    
}


/**
 如果是可以接受后续数据, 那么在接受过程中, 就会调用这个方法

 @param session 会话
 @param dataTask 任务
 @param data 接受到的数据, 一段
 */
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    
    _fileTmpSize += data.length;
    
    if (self.progressBlock) {
        self.progressBlock(1.0 * _fileTmpSize / _totalSize);
    }
    
    
    [self.outputStream write:data.bytes maxLength:data.length];

}



/**
 请求完毕, != 下载完毕

 @param session 会话
 @param task 任务
 @param error 错误
 */
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error
{
    
    
    if (!error) {
        // 开始字节 - 最后
        
        // w为了严谨, 再次验证
        // 文件完整性验证
        if (_fileTmpSize == _totalSize) {
            [XMGFileTool moveFileFromPath:self.downLoadingFilePath toPath:self.downLoadedFilePath];
            self.state = XMGDownLoaderStateSuccess;
        }
    }else {
        
        self.state = XMGDownLoaderStateFailed;
        // -999
        if(self.failedBlock)
        {
            self.failedBlock(error.localizedDescription);
        }
    }
    
    
    
}



#pragma mark - seter geter

- (NSURLSession *)session {
    if (!_session) {
        _session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:self delegateQueue:[NSOperationQueue new]];
    }
    return _session;
}
- (NSString *)downLoadingPath {
    
    NSString *path = [kCache stringByAppendingPathComponent:@"downLoader/downloading"];
    
    BOOL result = [XMGFileTool createDirectoryIfNotExists:path];
    if (result) {
        return path;
    }
    return @"";
    
}

- (NSString *)downLoadedPath {
    NSString *path = [kCache stringByAppendingPathComponent:@"downLoader/downloaded"];
    
    BOOL result = [XMGFileTool createDirectoryIfNotExists:path];
    if (result) {
        return path;
    }
    return @"";
}


- (void)setState:(XMGDownLoaderState)state {
//    if (_state == state) {
//        return;
//    }
    _state = state;
    
    if (self.stateChangeBlock) {
        self.stateChangeBlock(state);
    }
    
    
}


@end
