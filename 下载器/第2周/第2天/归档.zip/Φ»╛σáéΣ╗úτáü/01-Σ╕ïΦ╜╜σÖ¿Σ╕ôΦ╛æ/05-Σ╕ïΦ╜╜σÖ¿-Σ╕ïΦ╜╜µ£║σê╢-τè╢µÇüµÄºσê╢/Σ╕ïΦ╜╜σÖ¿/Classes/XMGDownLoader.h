//
//  XMGDownLoader.h
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, XMGDownLoaderState) {
    /** 下载暂停 */
    XMGDownLoaderStatePause,
    /** 正在下载 */
    XMGDownLoaderStateDowning,
    /** 已经下载 */
    XMGDownLoaderStateSuccess,
    /** 下载失败 */
    XMGDownLoaderStateFailed
};

typedef void(^DownLoadStateChange)(XMGDownLoaderState state);
typedef void(^DownLoadMessage)(long long totalSize, NSString *downLoadedPath);
typedef void(^DownLoadProgressChange)(float progress);
typedef void(^DownLoadSuccess)(NSString *downLoadedPath);
typedef void(^DownLoadFailed)(NSString *errorMsg);



@interface XMGDownLoader : NSObject

// 通知, 代理, block KVO
@property (nonatomic, assign, readonly) XMGDownLoaderState state;

@property (nonatomic, copy) DownLoadStateChange stateChangeBlock;
@property (nonatomic, copy) DownLoadMessage messageBlock;
@property (nonatomic, copy) DownLoadProgressChange progressBlock;
@property (nonatomic, copy) DownLoadSuccess successBlock;
@property (nonatomic, copy) DownLoadFailed failedBlock;


/**
 根据url地址下载

 @param url url地址
 */
- (void)downLoadWithURL:(NSURL *)url;
- (void)downLoadWithURL:(NSURL *)url messageBlock:(DownLoadMessage)messageBlock progress:(DownLoadProgressChange)progressBlock success:(DownLoadSuccess)successBlock failed:(DownLoadFailed)failedBlock;

- (void)cancel;

- (void)pause;

- (void)resume;


- (void)cancelAndClean;





@end
