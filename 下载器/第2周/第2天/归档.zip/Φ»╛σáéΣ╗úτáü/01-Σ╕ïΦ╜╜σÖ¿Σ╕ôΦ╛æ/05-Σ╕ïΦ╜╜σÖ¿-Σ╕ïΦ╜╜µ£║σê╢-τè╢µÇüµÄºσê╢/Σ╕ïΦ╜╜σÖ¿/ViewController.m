//
//  ViewController.m
//  下载器
//
//  Created by seemygo on 17/3/4.
//  Copyright © 2017年 seemygo. All rights reserved.
//

#import "ViewController.h"
#import "XMGDownLoader.h"

@interface ViewController ()

@property (nonatomic, strong) XMGDownLoader *downLoader;


@property (nonatomic, weak) NSTimer *timer;

@end

@implementation ViewController


- (NSTimer *)timer {
    if (!_timer) {
        NSTimer *timer = [NSTimer timerWithTimeInterval:1 target:self selector:@selector(update) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
        _timer = timer;
    }
    return _timer;
}

- (XMGDownLoader *)downLoader {
    if (!_downLoader) {
        _downLoader = [XMGDownLoader new];
    }
    return _downLoader;
}
- (IBAction)downLoaed:(id)sender {
    NSURL *url = [NSURL URLWithString:@"http://free2.macx.cn:8281/tools/photo/Sip44.dmg"];
//    [self.downLoader setStateChangeBlock:^(XMGDownLoaderState state){
//        NSLog(@"%zd", state);
//    }];
    [self.downLoader downLoadWithURL:url messageBlock:^(long long totalSize, NSString *downLoadedPath) {
        NSLog(@"开始下载--%@--%lld", downLoadedPath, totalSize);
    } progress:^(float progress) {
        NSLog(@"下载中--%f", progress);
    } success:^(NSString *downLoadedPath) {
        NSLog(@"完成");
    } failed:^(NSString *errorMsg) {
        NSLog(@"失败");
    }];
  
}
- (IBAction)cancel:(id)sender {
    [self.downLoader cancel];
}

- (IBAction)pause:(id)sender {
    [self.downLoader pause];
}
- (IBAction)resume:(id)sender {
    [self.downLoader resume];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self timer];
    
}


- (void)update {
    
//    NSLog(@"%zd", self.downLoader.state);
    
    
}


@end
