//
//  HWConst.m
//  黑马微博2期
//
//  Created by apple on 14-10-25.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <Foundation/Foundation.h>

// 账号信息
NSString * const HWAppKey = @"3235932662";
NSString * const HWRedirectURI = @"http://www.baidu.com";
NSString * const HWAppSecret = @"227141af66d895d0dd8baca62f73b700";

// 通知
// 表情选中的通知
NSString * const HWEmotionDidSelectNotification = @"HWEmotionDidSelectNotification";
NSString * const HWSelectEmotionKey = @"HWSelectEmotionKey";

// 删除文字的通知
NSString * const HWEmotionDidDeleteNotification = @"HWEmotionDidDeleteNotification";