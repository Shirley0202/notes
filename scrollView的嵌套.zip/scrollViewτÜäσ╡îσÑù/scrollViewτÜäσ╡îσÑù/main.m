//
//  main.m
//  scrollView的嵌套
//
//  Created by bobo on 17/1/15.
//  Copyright © 2017年 BFMXJY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
