//
//  ViewController.m
//  scrollView的嵌套
//
//  Created by bobo on 17/1/15.
//  Copyright © 2017年 BFMXJY. All rights reserved.
//

#import "ViewController.h"
#import "TableViewController.h"
#import "SecondTableViewController.h"
#define SCREEN_WIDTH 320

@interface ViewController ()<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *maiScrollView;
@property (nonatomic, strong) UIView*headView;
@property (nonatomic, assign) CGFloat lastTableViewOffsetY;

@property (nonatomic, strong) TableViewController *tvc;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.maiScrollView.delegate = self;
    
    
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self initUI];
    
    
   
}
-(void)initUI{
 
    self.maiScrollView.bounces = NO;
    TableViewController *tvc = [[TableViewController alloc]init];
    self.tvc =tvc;
    //    tvc.tableView.bounces = NO;
    tvc.view.frame = CGRectMake(0, 0, 320, 576);
    [self addChildViewController:tvc];
    [self.view   addSubview:tvc.view];
    tvc.tableView.contentInset = UIEdgeInsetsMake(200, 0, 0, 0);
    
    NSKeyValueObservingOptions options = NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld;
    [tvc.tableView addObserver:self forKeyPath:@"contentOffset" options:options context:nil];
    
    
    
    
    
    UIView  *headView = [[UIView alloc]init];
    self.headView = headView;
    headView.backgroundColor = [UIColor redColor];
    headView.frame = CGRectMake(0, 0, 320, 200);
    [self.view   addSubview:headView];
    self.maiScrollView.contentSize =CGSizeMake(0, 200+576);
    [headView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(HHH)]];
}
-(void)HHH{
//    self.tvc.num = 5;
//    [self.tvc.tableView reloadData];
    SecondTableViewController *vc = [[SecondTableViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];
}
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    
    
    UITableView *tableView = (UITableView *)object;
    
   
    
    if (![keyPath isEqualToString:@"contentOffset"]) {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
        return;
    }
    NSLog(@"%f",tableView.contentOffset.y);
    
    CGFloat tableViewoffsetY = tableView.contentOffset.y;
    
    self.lastTableViewOffsetY = tableViewoffsetY;
    CGFloat first = -200;
    CGFloat stop = -44;
    
    if ( tableViewoffsetY>=first && tableViewoffsetY<=stop) {
        
//        self.segmentScrollView.frame = CGRectMake(0, 200-tableViewoffsetY, SCREEN_WIDTH, 40);
        self.headView.frame = CGRectMake(0, -(tableViewoffsetY+200), SCREEN_WIDTH, 200);
        self.tvc.view.frame =CGRectMake(0, CGRectGetMinY(self.headView.frame), SCREEN_WIDTH, 200+576);
    }else if( tableViewoffsetY < first){
        
//        self.segmentScrollView.frame = CGRectMake(0, 200, SCREEN_WIDTH, 40);
        self.headView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 200);
        self.tvc.view.frame =CGRectMake(0, CGRectGetMinY(self.headView.frame), SCREEN_WIDTH, 200+576);
        
    }else if (tableViewoffsetY > stop){
        
//        self.segmentScrollView.frame = CGRectMake(0, 64, SCREEN_WIDTH, 40);
        self.headView.frame = CGRectMake(0, first-stop, SCREEN_WIDTH, 200);
         self.tvc.view.frame =CGRectMake(0, CGRectGetMinY(self.headView.frame), SCREEN_WIDTH, 200+576);
    }
}


@end
